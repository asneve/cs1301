package edu.westga.cs1301.adventuregame.test.shopitem;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.adventuregame.model.ShopItem;

public class TestConstructor {

	@Test
	public void testNullDescription() {
		assertThrows(IllegalArgumentException.class, () -> new ShopItem(null, 100, 100), "null description");
	}

	@Test
	public void testEmptyDescription() {
		assertThrows(IllegalArgumentException.class, () -> new ShopItem("", 100, 100), "empty description");
	}

	@Test
	public void testZeroQuantity() {
		assertThrows(IllegalArgumentException.class, () -> new ShopItem("Health Potion", 0, 1), "quantity is zero");
	}

	@Test
	public void testNegativeQuantity() {
		assertThrows(IllegalArgumentException.class, () -> new ShopItem("Health Potion", -1, 1), "quantity is negative");
	}

	@Test
	public void testAllowsQuantityAtMinimum() {
		ShopItem item = new ShopItem("Health Potion", 1, 1);
		assertEquals(1, item.getQuantity(), "minimum quantity allowed");
	}

	@Test
	public void testAllowsQuantityAtMaximum() {
		ShopItem item = new ShopItem("Health Potion", 250, 1);
		assertEquals(250, item.getQuantity(), "maximum quantity allowed");
	}

	@Test
	public void testNegativeCost() {
		assertThrows(IllegalArgumentException.class, () -> new ShopItem("Health Potion", 3, -2), "quantity is negative");
	}

	@Test
	public void testUnitCostOneGreaterThanMaximum() {
		assertThrows(IllegalArgumentException.class, () -> new ShopItem("Health Potion", 1, 451),
				"Unit cost one greater than maximum");
	}

	@Test
	public void testUnitCostTooExpensive() {
		assertThrows(IllegalArgumentException.class, () -> new ShopItem("Health Potion", 1, 475),
				"Unit cost much higher than maximum");
	}

	@Test
	public void testAllowsCostAtMinimum() {
		ShopItem item = new ShopItem("Adventure Advice", 3, 0);
		assertEquals(0, item.getUnitCost(), "Unit cost is free");
	}

	@Test
	public void testAllowsCostAtMaximum() {
		ShopItem item = new ShopItem("Iron Sword", 1, 450);
		assertEquals(450, item.getUnitCost(), "Maximum cost allowed");
	}

	@Test
	public void testValidItem() {
		ShopItem item = new ShopItem("Health Potion", 2, 50);
		assertEquals("Health Potion", item.getDescription(), "valid description");
		assertEquals(2, item.getQuantity(), "quantity within range");
		assertEquals(50, item.getUnitCost(), "cost within range"); 
	}

}
