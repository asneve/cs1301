package edu.westga.cs1301.adventuregame.test;

public class TestingConstants {

	public static final double DELTA = 0.00001;

}