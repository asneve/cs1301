package edu.westga.cs1301.adventuregame.test.shoporder;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edu.westga.cs1301.adventuregame.model.ShopItem;
import edu.westga.cs1301.adventuregame.model.ShopOrder;

/**
 * Testing highest Quantity
 * @author CS1301 Spring - 2021
 *
 */
public class TestFindHighestQuantity {
	private LocalDate CurrentDate;
	private ShopOrder CurrentOrder;
	
	@BeforeEach
	protected void Setup() {
		this.CurrentDate = LocalDate.now();
		this.CurrentOrder = new ShopOrder(this.CurrentDate);
	}
	
	@AfterEach
	protected void TearDown() {
		this.CurrentDate = null;
		this.CurrentOrder = null;
	}

	@Test
	public void testHighestQuanitityShouldBeIntegerZeroIfNoItems() {
		assertEquals(0, this.CurrentOrder.findItemCountWithMostUnits());
	}

	@Test
	public void testHighestQuanitityShouldBeOnlyItem() {
		this.CurrentOrder.addItem(new ShopItem("Health Potion", 25, 50));
		int result = this.CurrentOrder.findItemCountWithMostUnits();
		
		assertEquals(25, result);
	}

	@Test
	public void testHighestQuantityShouldBeFirstItem() {
		ShopItem[] itemsToAdd = {
				new ShopItem("Health Potion", 25, 12),
				new ShopItem("Wood Arrow", 5, 2),
				new ShopItem("Gold Sword", 1, 500)
				};
		
		for (ShopItem item : itemsToAdd) {
			this.CurrentOrder.addItem(item);
		};
		
		assertEquals(25, this.CurrentOrder.findItemCountWithMostUnits(), "25 is highest quantity");
	}

	@Test
	public void testHighestQuantityShouldBeMiddleItem() {
		ShopItem[] itemsToAdd = {
				new ShopItem("Health Potion", 1, 12),
				new ShopItem("Wood Arrow", 25, 2),
				new ShopItem("Gold Sword", 1, 500)
				};
		
		for (ShopItem item : itemsToAdd) {
			this.CurrentOrder.addItem(item);
		};
		
		assertEquals(25, this.CurrentOrder.findItemCountWithMostUnits(), "25 is highest quantity");
	}

	@Test
	public void testHighestQuantityShouldBeLastItem() {
		ShopItem[] itemsToAdd = {
				new ShopItem("Health Potion", 1, 12),
				new ShopItem("Wood Arrow", 1, 2),
				new ShopItem("Gold Sword", 25, 500)
				};
		
		for (ShopItem item : itemsToAdd) {
			this.CurrentOrder.addItem(item);
		};
		
		assertEquals(25, this.CurrentOrder.findItemCountWithMostUnits(), "25 is highest quantity");
	}

	@Test
	public void testHighestQuantityWhenTwoItemsSameQuantity() {
		ShopItem[] itemsToAdd = {
				new ShopItem("Health Potion", 25, 12),
				new ShopItem("Wood Arrow", 25, 2),
				new ShopItem("Gold Sword", 1, 500)
				};
		
		for (ShopItem item : itemsToAdd) {
			this.CurrentOrder.addItem(item);
		};
		
		assertEquals(25, this.CurrentOrder.findItemCountWithMostUnits(), "25 is highest quantity");
	}

	@Test
	public void testHighestQuantityWhenAllItemsSameQuantity() {
		ShopItem[] itemsToAdd = {
				new ShopItem("Health Potion", 25, 12),
				new ShopItem("Wood Arrow", 25, 2),
				new ShopItem("Gold Sword", 25, 500)
				};
		
		for (ShopItem item : itemsToAdd) {
			this.CurrentOrder.addItem(item);
		};
		
		assertEquals(25, this.CurrentOrder.findItemCountWithMostUnits(), "25 is highest quantity");
	}

}
