package edu.westga.cs1301.adventuregame.test.shoporder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.LocalDate;
import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edu.westga.cs1301.adventuregame.model.ShopItem;
import edu.westga.cs1301.adventuregame.model.ShopOrder;

/**
 * Testing Add Shop Item
 * @author CS1301 - Spring 2021
 *
 */
public class TestAddShopItem {
	private LocalDate CurrentDate;
	private ShopOrder CurrentOrder;
	
	@BeforeEach
	protected void Setup() {
		this.CurrentDate = LocalDate.now();
		this.CurrentOrder = new ShopOrder(this.CurrentDate);
	}
	
	@AfterEach
	protected void TearDown() {
		this.CurrentDate = null;
		this.CurrentOrder = null;
	}
	

	@Test
	public void testNotAddNull() {	
		assertThrows(IllegalArgumentException.class, () -> this.CurrentOrder.addItem(null));
	}

	@Test
	public void testAddOneItem() {
		ShopItem item = new ShopItem("Health Potion", 10, 12);
		this.CurrentOrder.addItem(item);
	
		assertEquals(1, this.CurrentOrder.getNumberOfShopItems(), "Checking the size of the order");
		// Note: Not actually looking at the specifics of the ShopItem to compare value
		assertEquals(item, this.CurrentOrder.getItems().get(0), ("Checking the only item added."));
	}

	@Test
	public void testAddManyMaterials() {
		ShopItem[] itemsToAdd = {
				new ShopItem("Health Potion", 10, 12),
				new ShopItem("Wood Arrow", 25, 2),
				new ShopItem("Gold Sword", 1, 500)
				};
		
		for (ShopItem item : itemsToAdd) {
			this.CurrentOrder.addItem(item);
		};
		
		ArrayList<ShopItem> shopItems = this.CurrentOrder.getItems();
	
		assertEquals(3, this.CurrentOrder.getNumberOfShopItems(), "Checking the size of the order.");
		// Note: Not actually looking at the specifics of the ShopItem to compare value
		assertEquals(itemsToAdd[0], shopItems.get(0));
		assertEquals(itemsToAdd[1], shopItems.get(1));
		assertEquals(itemsToAdd[2], shopItems.get(2));
	}

}
