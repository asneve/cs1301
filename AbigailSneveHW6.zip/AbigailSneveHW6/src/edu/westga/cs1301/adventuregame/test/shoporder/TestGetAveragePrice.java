package edu.westga.cs1301.adventuregame.test.shoporder;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edu.westga.cs1301.adventuregame.model.ShopItem;
import edu.westga.cs1301.adventuregame.model.ShopOrder;
import edu.westga.cs1301.adventuregame.test.TestingConstants;

/**
 * Test Get Average Price
 * @author CS1301 Spring - 2021
 *
 */
public class TestGetAveragePrice {
	private LocalDate CurrentDate;
	private ShopOrder CurrentOrder;
	
	@BeforeEach
	protected void Setup() {
		this.CurrentDate = LocalDate.now();
		this.CurrentOrder = new ShopOrder(this.CurrentDate);
	}
	
	@AfterEach
	protected void TearDown() {
		this.CurrentDate = null;
		this.CurrentOrder = null;
	}

	@Test
	public void testGetSentinelWhenOrderHasNoMaterials() {
		double average = this.CurrentOrder.getAveragePrice();
		
		assertEquals(Double.MIN_VALUE, average, TestingConstants.DELTA);
	}

	@Test
	public void testGetAverageWhenOrderOnlyHasOneMaterial() {
		ShopItem item1 = new ShopItem("charcoal paver", 5, 20);
		this.CurrentOrder.addItem(item1);

		double average = this.CurrentOrder.getAveragePrice();
		assertEquals(100.0, average, TestingConstants.DELTA);
	}

	@Test
	public void testGetAverageWhenOrderHasManyMaterials() {
		ShopItem[] itemsToAdd = {
				new ShopItem("Health Potion", 1, 100),
				new ShopItem("Wood Arrow", 5, 7),
				new ShopItem("Gold Sword", 1, 200)
				};
		
		for (ShopItem item : itemsToAdd) {
			this.CurrentOrder.addItem(item);
		};

		double average = this.CurrentOrder.getAveragePrice();
		assertEquals(111.00, average, TestingConstants.DELTA);
	}

}
