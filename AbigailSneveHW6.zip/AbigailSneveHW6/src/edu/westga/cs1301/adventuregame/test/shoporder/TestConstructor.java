package edu.westga.cs1301.adventuregame.test.shoporder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.adventuregame.model.ShopOrder;

/**
 * Testing ShopOrder Constructor 
 * @author CS1301 Spring - 2021
 *
 */
public class TestConstructor {

	@Test
	public void testNullDate() {
		assertThrows(IllegalArgumentException.class, () -> new ShopOrder(null), "null date");
	}

	@Test
	public void testWhenNoItemsInOrder() {
		LocalDate date = LocalDate.now();
		ShopOrder order = new ShopOrder(date);
		
		assertEquals(0, order.getItems().size());
	}

}
