package edu.westga.cs1301.adventuregame.model;

import java.time.LocalDate;
import java.util.ArrayList;


/**
 * Creates an order of items from the adventure store.
 * 
 * @author Abigail Sneve CS1301
 * @version Spring 2022
 */
public class ShopOrder {
	private LocalDate date;
	private ArrayList <ShopItem> items;
	
	
		
	/**
	 * Creates a new ShopOrder with no items
	 * 
	 * @precondition date != null
	 * @postcondition getDate() == date && getNumberOfShopItems() == 0
	 * 
	 * @param date the date of the order
	 */
	public ShopOrder(  LocalDate date) {
		if (date == null) {
			throw new IllegalArgumentException("Date of the order cannot be null.");
		}
		this.date = date;
		this.items = new ArrayList <ShopItem>();
	}
	
	/**
	 * Return the date of the order.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return date the date of this order
	 */
	public LocalDate getOrderDate() {
		return this.date;
	}

	/**
	 * Gets all the items
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the collection of items
	 */
	public ArrayList<ShopItem> getItems(){
		return this.items;
	}
	
	/**
	 * Adds a new ShopItem to this order.
	 * 
	 * @precondition item != null
	 * @postcondition getNumberOfShopItems() = getNumberOfShopItems()@prev + 1
	 * 
	 * @param item the item to add to this order
	 */
	public void addItem(ShopItem item){
		if(item == null) {
			throw new IllegalArgumentException("The item is nonexistant");
		}

		this.items.add(item);
	}

	/**
	 * Gets the number of items in this order.
	 * @return 
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the number of items in this order.
	 */
	public int getNumberOfShopItems() {
		return this.items.size();
	}

	/**
	 * Gets the average price (unit cost times quantity) of all requested items
	 * in this order.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the average of all requested items in this order, or
	 *         Double.MIN_VALUE if no items.
	 */
	
	public double getAveragePrice() {
		int average=0;
		int total=0;
		for(ShopItem ShopItem : items) {
			total = ShopItem.getUnitCost() * ShopItem.getQuantity() + total;
			average = total/this.getNumberOfShopItems();
		}
		return average;
}
	/**
	 * Gets the total quantity of the item with the highest quantity in this order
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return Zero if no items, 
	 * quantity of the item in the order with the highest quantity
	 */
	
	public int findItemCountWithMostUnits() {
		 int highestQuantity = 0;
		
		 int nItem;
		 int cItem;
		for ( int i = 0; i < this.getNumberOfShopItems() - 1 ; i++) {
			ShopItem currItem = this.items.get(i);
			ShopItem nextItem = this.items.get(i+ 1);
			cItem = currItem.getQuantity();
			nItem= nextItem.getQuantity();
			
			if (cItem >= nItem) {
				highestQuantity = cItem;
			
			}

			if (cItem <= nItem) {
				highestQuantity = nItem;
				
			}

			
		}
		
		return highestQuantity;
		}
		

		
	}

