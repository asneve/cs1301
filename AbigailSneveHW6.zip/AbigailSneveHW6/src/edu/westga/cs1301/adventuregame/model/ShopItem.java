package edu.westga.cs1301.adventuregame.model;

/**
 * Stores information for a single adventure store item.
 * 
 * @author Abigail Sneve CS1301
 * @version Spring 2022
 */
public class ShopItem {

	public static final int MAX_UNIT_COST = 500;
	public static final int MIN_QUANTITY = 1;
	public static final int MAX_QUANTITY = 250;
	private String description;
	private int quantity;
	private int unitCost;

	/**
	 * Create a new item with the specified description, quantity, and unit
	 * cost.
	 * 
	 * @precondition description != null && !description.isEmpty() && MIN_QUANTITY
	 *               <= quantity <= MAX_QUANTITY && 0 <= unitCost <= MAX_UNIT_COST
	 * 
	 * @postcondition getDescription().equals(description) && getQuantity() ==
	 *                quantity && getUnitCost() == unitCost
	 * 
	 * @param description
	 *            description of the item
	 * @param quantity
	 *            the number of units
	 * @param unitCost
	 *            the cost per unit
	 */
	public ShopItem(String description, int quantity, int unitCost) {

		if (description == null || description.isEmpty())
			throw new IllegalArgumentException("A valid scription must be provided.");

		if (quantity < ShopItem.MIN_QUANTITY)
			throw new IllegalArgumentException("Quantity must be at least 1.");

		if (quantity > ShopItem.MAX_QUANTITY)
			throw new IllegalArgumentException("Quantities larger than 250 are not accepted.");

		if (unitCost > ShopItem.MAX_UNIT_COST)
			throw new IllegalArgumentException("Items more expensive than 450 gold/unit are not accepted.");

		if (unitCost < 0)
			throw new IllegalArgumentException("Item cannot have a negative price.");

		this.description = description;
		this.quantity = quantity;
		this.unitCost = unitCost;

	}

	/**
	 * Return the description of the item.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return description the description of this item
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 * Return the quantity of the item.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return quantity the quantity of this item
	 */
	public int getQuantity() {
		return this.quantity;
	}

	/**
	 * Return the unit cost of the item.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return unitCost the cost per unit of this item
	 */
	public int getUnitCost() {
		return this.unitCost;
	}

}
