package edu.westga.cs1301.p2.model;

/**
 * Manages information needed by a sales associate.
 * 
 * @author Abigail Sneve CS 1301 Extra Credit
 * @version April 6, Spring 2022
 */
public class SalesAssociate {
	private CarInventory inventory1;
	private CarInventory inventory2;
	private String name;

	/**
	 * Creates a sales associate that manages the specified inventory of cars.
	 *
	 * @precondition inventory1 != null && inventory2 != null && name != null &&
	 *               !name.isEmpty()
	 * @postcondition getInventory1().getModel() == inventory1.getModel() &&
	 *                getInventory2().getModel() == inventory2.getModel() &&
	 *                getInventory1().getLastNumber() == inventory1.getLastNumber()
	 *                && getInventory2().getLastNumber() ==
	 *                inventory2.getLastNumber() && getName() == name
	 *
	 * @param inventory1 the first CarInventory managed by the sales associate
	 * @param inventory2 the second CarInventory managed by the sales associate
	 * @param name       the name of the sales associate
	 */

	public SalesAssociate(CarInventory inventory, CarInventory inventory1, String name) {
		this.inventory1 = inventory;
		this.inventory2 = inventory1;
		this.name = name;
		if (inventory == null) {
			throw new IllegalArgumentException("first inventory is null");
		}
		if (inventory1 == null) {
			throw new IllegalArgumentException("second inventory is null");
		}
		if (name == null) {
			throw new IllegalArgumentException("name is null");
		}

		if (name == "") {
			throw new IllegalArgumentException("name is empty");
		}

	}

	/**
	 * Check if the sales associate is responsible for the specified inventory
	 *
	 * @precondition carModel != null && inventoryNumber > 0
	 * @postcondition none
	 *
	 * @param carModel        the model of car in inventory
	 * @param inventoryNumber the number for the inventory item
	 *
	 * @return true if the car model is in one of the two car inventories false if
	 *         the model is *not* in one of the two car inventories
	 */

	public boolean isSalesAssociateForInventory(String carModel, int inventoryNumber) {

		if (carModel == null) {
			throw new IllegalArgumentException("model is null");
		}
		if (inventoryNumber == 0) {
			throw new IllegalArgumentException("There is no inventory");
		}
		if (inventoryNumber < 0) {
			throw new IllegalArgumentException("The inventory is negative");
		}
		if (carModel == this.inventory1.getModel()) {
			if (inventoryNumber <= this.inventory1.getLastNumber()) {
				return true;
			}
		}
		if (carModel == this.inventory2.getModel()) {
			if (inventoryNumber <= this.inventory2.getLastNumber()) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Gets the information for all models in inventory that the sales associate is
	 * responsible for.
	 *
	 * Each model and inventory number should each appear on a separate line, and
	 * each item must be in the following format:
	 *
	 * <model> <inventory number>
	 *
	 * For example, suppose Suzie is the sales associate, if the last inventory
	 * number is 3 and the model of the cars is BMW and Toyota; then the String
	 * returned would be:
	 *
	 * Car Inventory for Suzie: BMW 1 BMW 2 BMW 3 Toyota 1 Toyota 2 Toyota 3
	 *
	 * @precondition none
	 * @postcondition none
	 *
	 * @return the list of cars for the sales associate
	 */
	public String getAllInventory() {
		String inventory = "Inventory for " + this.name + ":" + System.lineSeparator()
				+ this.inventory1.getAllInventory() + this.inventory2.getAllInventory();
		return inventory;
	}

	/**
	 * Returns a comma separated inventory list for the sales associate that starts
	 * and ends with the specified numbers and contains all numbers in between. Each
	 * number should be on a new line.
	 *
	 * @precondition startNumber > 0 && endNumber > 0 && startNumber < endNumber
	 * @postcondition none
	 *
	 *                2, 3, 4,
	 *
	 * @param startNumber the 1st number that should appear on the inventory list
	 * @param endNumber   the last number that should appear on the inventory list
	 *
	 * @return the inventory list
	 */

	public String getInventoryList(int startNumber, int endNumber) {
		String inventoryList = "";
		if (startNumber < 0) {
			throw new IllegalArgumentException("Starting number is too low");
		}
		if (endNumber < 0) {
			throw new IllegalArgumentException("Ending number is too low");
		}
		if (startNumber == 0) {
			throw new IllegalArgumentException("start cannot be 0");
		}
		if (startNumber >= endNumber) {
			throw new IllegalArgumentException("start number is larger than end number");
		}
		for (int i = 0; i <= endNumber; i++) {
			if (i >= startNumber) {
				inventoryList = (inventoryList + i + System.lineSeparator());
			}
		}

		return inventoryList;

	}

	/**
	 * @return the inventory1
	 */
	public CarInventory getInventory1() {
		return inventory1;
	}

	/**
	 * @return the inventory2
	 */
	public CarInventory getInventory2() {
		return inventory2;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

}
