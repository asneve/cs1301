package edu.westga.cs1301.p2.model;

/**
 * Stores and manages information for a CarInventory handled by a Sales
 * Associate.
 * 
 * @author Abigail Sneve CS 1301 Extra Credit
 * @version April 6, Spring 2022
 */
public class CarInventory {
	private int lastNumber;
	private String modelString;
	private String inventory;

	/**
	 * Establishes the state of the new CarInventory object with the following
	 * information.
	 * 
	 * @return
	 * @precondition none
	 * @postcondition getModel () == �Not Assigned� && getLastNumber() == 0
	 */
	public CarInventory() {
		getModel();
		getLastNumber();

	}

	/**
	 * Establishes the state of the new CarInventory with the information provided.
	 * 
	 * @precondition model != null && !model.isEmpty() && lastNumber > 0
	 * @postcondition getModel() == name && getLastNumber() == lastNumber
	 *
	 * @param model      the model of the Car
	 * @param lastNumber the number of the last car in inventory
	 */

	public CarInventory(String modelString, int lastNumber) {
		this.modelString = modelString;
		if (this.modelString == null) {
			this.modelString = "Not Assigned";
			throw new IllegalArgumentException("string is null");
		}
		if (this.modelString == "") {
			this.modelString = "Not Assigned";
			throw new IllegalArgumentException("string is empty");
		}

		this.lastNumber = lastNumber;

		if (this.lastNumber == 0) {

			throw new IllegalArgumentException("Number is 0");
		}
		if (this.lastNumber < 0) {

			throw new IllegalArgumentException("Number is negative");
		}
		getModel();
		getLastNumber();

	}

	/**
	 * Checks if the listed car inventory number matches a car in this inventory
	 *
	 * @precondition modelInventoryNumber > 0
	 * @postcondition none
	 *
	 * @param modelInventoryNumber the inventory number of the Car to check for
	 *
	 * @return true if the car is in the inventory false if the car is *not* in
	 *         inventory
	 */

	public boolean isCarInInventory(int modelInventoryNumber) {
		if (modelInventoryNumber <= 0) {
			throw new IllegalArgumentException("Inventory number does not exist.");
		} else {
			if (modelInventoryNumber <= lastNumber) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Gets the text for all cars in the car inventory.
	 *
	 * The car should each appear on a separate line, and each entry must be in the
	 * following format:
	 *
	 * <model> <number>
	 *
	 * For example, if the number of the last car in the car inventory was 3 and the
	 * model of the car inventory was BMW, then the String returned would be:
	 *
	 * BMW 1 BMW 2 BMW 3
	 *
	 * @precondition none
	 * @postcondition none
	 *
	 * @return the list of all model numbers in inventory
	 */

	public String getAllInventory() {
		inventory = "";
		for (int i = 1; i <= getLastNumber(); i++) {
			if (i == 1) {
				inventory = (getModel() + " " + i + System.lineSeparator());
			} else {
				inventory = (inventory + getModel() + " " + i + System.lineSeparator());
			}
		}

		return inventory;

	}

	/**
	 * @return the lastNumber
	 */
	public int getLastNumber() {

		return lastNumber;
	}

	public String getModel() {
		if (this.modelString == null) {
			this.modelString = "Not Assigned";

		}
		if (this.modelString == "") {
			this.modelString = "Not Assigned";

		}

		return modelString;
	}
}
