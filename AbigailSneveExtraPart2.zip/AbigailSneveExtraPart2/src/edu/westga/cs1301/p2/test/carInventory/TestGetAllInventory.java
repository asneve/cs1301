package edu.westga.cs1301.p2.test.carInventory;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.p2.model.CarInventory;

class TestGetAllInventory {

	@Test
	void testOneCarInInventory() {
		CarInventory car = new CarInventory("a", 1);
		
		String result = car.getAllInventory();
		
		String expected = "a 1" + System.lineSeparator();
		assertEquals(expected, result);
	}

	@Test
	void testMultipleCarsInInventory() {
		CarInventory car = new CarInventory("a", 2);
		
		String result = car.getAllInventory();
		
		String expected = "a 1" + System.lineSeparator() + "a 2" + System.lineSeparator();
		assertEquals(expected, result);
	}

}
