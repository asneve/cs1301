package edu.westga.cs1301.p2.test.carInventory;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.p2.model.CarInventory;

class TestIsCarInInventory {

	@Test
	void testNegativeInventoryNumber() {
		CarInventory inventory = new CarInventory("a", 1);
		
		
		assertThrows(IllegalArgumentException.class, ()->{
			inventory.isCarInInventory(-1);
		});
	}

	@Test
	void testZeroInventoryNumber() {
		CarInventory inventory = new CarInventory("a", 1);
		
		
		assertThrows(IllegalArgumentException.class, ()->{
			inventory.isCarInInventory(0);
		});
	}

	@Test
	void testLastInventoryNumber() {
		CarInventory inventory = new CarInventory("a", 1);
		
		boolean result = inventory.isCarInInventory(1);
		
		assertTrue(result);
	}

	@Test
	void testInventoryNumberBeforeLastInventoryNumber() {
		CarInventory inventory = new CarInventory("a", 2);
		
		boolean result = inventory.isCarInInventory(1);
		
		assertTrue(result);
	}

	@Test
	void testInventoryNumberIsAfterMaxInventoryNumber() {
		CarInventory inventory = new CarInventory("a", 1);
		
		boolean result = inventory.isCarInInventory(2);
		
		assertFalse(result);
	}

}
