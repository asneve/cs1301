package edu.westga.cs1301.p2.test.carInventory;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.p2.model.CarInventory;

class TestZeroParamConstructor {

	@Test	
	void testValidStreet() {
		CarInventory result = new CarInventory();
		
		assertEquals("Not Assigned", result.getModel(), "checking model");
		assertEquals(0, result.getLastNumber(), "checking last number");
	}

}
