package edu.westga.cs1301.p2.test.salesAssociate;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.p2.model.SalesAssociate;
import edu.westga.cs1301.p2.model.CarInventory;

class TestGetInventoryList {

	@Test
	void testNegativeStartNumber() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(inventory1, inventory2, "John");

		assertThrows(IllegalArgumentException.class, () -> {
			sa.getInventoryList(-1, 2);
		});
	}

	@Test
	void testZeroStartNumber() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(inventory1, inventory2, "John");

		assertThrows(IllegalArgumentException.class, () -> {
			sa.getInventoryList(0, 2);
		});
	}

	@Test
	void testNegativeEndNumber() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(inventory1, inventory2, "John");

		assertThrows(IllegalArgumentException.class, () -> {
			sa.getInventoryList(1, -1);
		});
	}

	@Test
	void testZeroEndNumber() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(inventory1, inventory2, "John");

		assertThrows(IllegalArgumentException.class, () -> {
			sa.getInventoryList(1, 0);
		});
	}

	@Test
	void testStartNumberEqualsEndNumber() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(inventory1, inventory2, "John");

		assertThrows(IllegalArgumentException.class, () -> {
			sa.getInventoryList(1, 1);
		});
	}

	@Test
	void testStartNumberIsAfterEndNumber() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(inventory1, inventory2, "John");

		assertThrows(IllegalArgumentException.class, () -> {
			sa.getInventoryList(2, 1);
		});
	}

	@Test
	void testMinimumNumbersInInventoryList() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(inventory1, inventory2, "John");

		String result = sa.getInventoryList(1, 2);

		String expected = "1" + System.lineSeparator() + "2" + System.lineSeparator();

		assertEquals(expected, result);
	}

	@Test
	void testStartNumberIsAbove1() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(inventory1, inventory2, "John");

		String result = sa.getInventoryList(3, 5);

		String expected = "3" + System.lineSeparator();
		expected += "4" + System.lineSeparator();
		expected += "5" + System.lineSeparator();

		assertEquals(expected, result);
	}
}
