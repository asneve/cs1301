package edu.westga.cs1301.p2.test.salesAssociate;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.p2.model.SalesAssociate;
import edu.westga.cs1301.p2.model.CarInventory;

class TestIsSalesAssociateForInventory {

	@Test
	void testNullName() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(inventory1, inventory2, "John");

		assertThrows(IllegalArgumentException.class, () -> {
			sa.isSalesAssociateForInventory(null, 1);
		});
	}

	@Test
	void testNegativeInventoryNumber() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(inventory1, inventory2, "John");

		assertThrows(IllegalArgumentException.class, () -> {
			sa.isSalesAssociateForInventory("a", -1);
		});
	}

	@Test
	void testZeroInventoryNumber() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(inventory1, inventory2, "John");

		assertThrows(IllegalArgumentException.class, () -> {
			sa.isSalesAssociateForInventory("a", 0);
		});
	}

	@Test
	void testInventoryNumberIsLastOnFirstInventory() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(inventory1, inventory2, "John");

		boolean result = sa.isSalesAssociateForInventory("first", 1);

		assertTrue(result);
	}

	@Test
	void testInventoryNumberIsBeforeLastOnFirstInventory() {
		CarInventory inventory1 = new CarInventory("first", 2);
		CarInventory inventory2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(inventory1, inventory2, "John");

		boolean result = sa.isSalesAssociateForInventory("first", 1);

		assertTrue(result);
	}

	@Test
	void testInventoryNumberIsAfterLastOnFirstInventory() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(inventory1, inventory2, "John");

		boolean result = sa.isSalesAssociateForInventory("first", 2);

		assertFalse(result);
	}

	@Test
	void testInventoryNumberIsLastOnSecondInventory() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(inventory1, inventory2, "John");

		boolean result = sa.isSalesAssociateForInventory("second", 2);

		assertTrue(result);
	}

	@Test
	void testInventoryNumberIsBeforeLastOnSecondInventory() {
		CarInventory street1 = new CarInventory("first", 2);
		CarInventory street2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(street1, street2, "John");

		boolean result = sa.isSalesAssociateForInventory("second", 1);

		assertTrue(result);
	}

	@Test
	void testInventoryNumberIsAfterLastOnSecondInventory() {
		CarInventory street1 = new CarInventory("first", 1);
		CarInventory street2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(street1, street2, "John");

		boolean result = sa.isSalesAssociateForInventory("second", 3);

		assertFalse(result);
	}

	@Test
	void testInventoryIsNotRepresentedByRepresentative() {
		CarInventory street1 = new CarInventory("first", 1);
		CarInventory street2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(street1, street2, "John");

		boolean result = sa.isSalesAssociateForInventory("third", 1);

		assertFalse(result);
	}
}
