package edu.westga.cs1301.p2.test.carInventory;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.p2.model.CarInventory;

class TestTwoParamConstructor {

	@Test
	void testNullName() {
		assertThrows(IllegalArgumentException.class, ()->{
			new CarInventory(null, 3);
		});
	}

	@Test
	void testEmptyName() {
		assertThrows(IllegalArgumentException.class, ()->{
			new CarInventory("", 3);
		});
	}

	@Test
	void testNegativeLastNumber() {
		assertThrows(IllegalArgumentException.class, ()->{
			new CarInventory("a", -1);
		});
	}

	@Test
	void testZeroLastNumber() {
		assertThrows(IllegalArgumentException.class, ()->{
			new CarInventory("a", 0);
		});
	}
	
	@Test
	void testValidInventory() {
		CarInventory result = new CarInventory("a", 1);
		
		assertEquals("a", result.getModel(), "checking model");
		assertEquals(1, result.getLastNumber(), "checking last number");
	}
}
