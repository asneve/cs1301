package edu.westga.cs1301.p2.test.salesAssociate;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.p2.model.SalesAssociate;
import edu.westga.cs1301.p2.model.CarInventory;

class TestConstructor {

	@Test
	void testNullStreet1() {
		CarInventory inventory = new CarInventory("second", 2);
		
		assertThrows(IllegalArgumentException.class, ()->{
			new SalesAssociate(null, inventory, "John");
		});
	}

	@Test
	void testNullStreet2() {
		CarInventory inventory = new CarInventory("first", 1);
		
		assertThrows(IllegalArgumentException.class, ()->{
			new SalesAssociate(inventory, null, "John");
		});
	}
	
	@Test
	void testNullName() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 2);
		assertThrows(IllegalArgumentException.class, ()->{
			new SalesAssociate(inventory1, inventory2, null);
		});
	}

	@Test
	void testEmptyName() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 2);
		assertThrows(IllegalArgumentException.class, ()->{
			new SalesAssociate(inventory1, inventory2, "");
		});
	}

	@Test
	void testBothValidStreets() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 2);
		
		SalesAssociate result = new SalesAssociate(inventory1, inventory2, "John");
		
		assertEquals("first", result.getInventory1().getModel(), "checking Model of the first Inventory");
		assertEquals("second", result.getInventory2().getModel(), "checking Model of the second Inventory");
		assertEquals(1, result.getInventory1().getLastNumber(), "checking last number of the first Inventory");
		assertEquals(2, result.getInventory2().getLastNumber(), "checking last number of the second Inventory");
		assertEquals("John", result.getName(), "checking the representatives name");
	}

}
