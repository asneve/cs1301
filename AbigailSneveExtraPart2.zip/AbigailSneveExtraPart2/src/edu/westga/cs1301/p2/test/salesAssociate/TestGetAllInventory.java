package edu.westga.cs1301.p2.test.salesAssociate;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.p2.model.SalesAssociate;
import edu.westga.cs1301.p2.model.CarInventory;

class TestGetAllInventory {

	@Test
	void testOneCarInBothInventories() {
		CarInventory inventory1 = new CarInventory("first", 1);
		CarInventory inventory2 = new CarInventory("second", 1);
		SalesAssociate sa = new SalesAssociate(inventory1, inventory2, "John");
		
		String result = sa.getAllInventory();
		
		String expected = "Inventory for John:"+ System.lineSeparator() + "first 1" + System.lineSeparator() + "second 1" + System.lineSeparator();
		assertEquals(expected, result);
	}

	@Test
	void testMultipleCarsInBothInventorys() {
		CarInventory inventory1 = new CarInventory("first", 2);
		CarInventory inventory2 = new CarInventory("second", 2);
		SalesAssociate sa = new SalesAssociate(inventory1, inventory2, "John");
		
		String result = sa.getAllInventory();
		
		String expected = "Inventory for John:"+ System.lineSeparator() + "first 1" + System.lineSeparator() + "first 2" + System.lineSeparator();
		expected += "second 1" + System.lineSeparator() + "second 2" + System.lineSeparator();
		assertEquals(expected, result);
	}

}
