package edu.westga.cs1301.p1.controllers;


import edu.westga.cs1301.p1.model.Turtle;
/**
 * Uses Turtle objects to draw on the screen.
 * 
 * @author CS 1301
 * @version Spring 2022
 */
public class TurtleController {
	//TODO part 1 - add big turtle fiel
	private Turtle bigTurtle; 
	//TODO part 2 - add small turtle field
	private Turtle smallTurtle;
	
	
	
	/**
	 * Creates and initializes a new TurtleController object.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 */
	public TurtleController() {
		//TODO part 1 - initialize big turtle fieldx
		this.bigTurtle = new Turtle(50,0.9);
		this.smallTurtle = new Turtle(20,0.8);
		//TODO part 2 - initialize small turtle field
		
	}

	/**
	 * Draws a figure on the screen using turtle objects.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public void draw() {
		this.bigTurtle.setLocation(75, 325);
		
		//TODO part 1 - draw house frame with big turtle
		this.bigTurtle.lowerTail();
		halfFrame();///6
		
		halfFrame();//12
		

		//TODO part 1 - draw roof with big turtle
		this.bigTurtle.turnLeft(30);
		this.bigTurtle.turnLeft(30);
		bTurtle350();//18
		

		this.bigTurtle.turnRight(120);
		bTurtle350();//24
		

		//TODO part 2 - draw door with small turtle
		this.smallTurtle.setLocation(200, 625);//sets to the middle
		s60Length();//3
		
		this.smallTurtle.turnLeft(90);
		this.smallTurtle.lowerTail();
		s60Length();//6
		

		s60Length();//9
		

		this.smallTurtle.turnLeft(90);
		s60Length();//12
		

		this.smallTurtle.turnLeft(90);
		s60Length();//1	
	

		s60Length();//18
		
		;
		
		//TODO part 2 - draw 2 windows with small turtle
		this.smallTurtle.setLocation(200, 400);
		window();//32
		

		this.smallTurtle.setLocation(260, 400);
		this.smallTurtle.lowerTail();
		window();//44
		

	}

	private void window() {
		s60Length();//+3
		windowWall();//+3
		windowWall();//+3
		windowWall();//+3
	}

	private void windowWall() {
		this.smallTurtle.turnRight(90);
		s60Length();
	}

	private void s60Length() {
		this.smallTurtle.stepForward();
		this.smallTurtle.stepForward();
		this.smallTurtle.stepForward();
	}

	private void bTurtle350() {
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();//100
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();//200
		this.bigTurtle.stepForward();
		this.bigTurtle.stepForward();//300
		
	}

	private void halfFrame() {
		bTurtle350();//6
		this.bigTurtle.turnRight(30);
		this.bigTurtle.turnRight(30);
		this.bigTurtle.turnRight(30);
		bTurtle350();//6
		this.bigTurtle.turnRight(30);
		this.bigTurtle.turnRight(30);
		this.bigTurtle.turnRight(30);
	}
		
	private void printStatus (Turtle turtle, String name) {
		int size = turtle.getSizeStatus();
		double speed = turtle.getSpeedStatus();
		System.out.println(name + " size is: " + size);
		System.out.println(name + " speed is : " + speed);
	}
		private void printTurtleSteps (Turtle turtle, String name) {
			
	 int turtleSteps = turtle.getStepCount();
	 System.out.println(name + " took this many steps : " + turtleSteps);
	 }
	
	/** 
	 * Print summary statistics about the turtles.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public void print() {
		printStatus(this.bigTurtle, "Big Turtle");
		printStatus(this.smallTurtle,"Small Turtle");
		//TODO part 1 - print summary statistics about big turtle
		printTurtleSteps(this.bigTurtle, "Big Turtle");
		
		//TODO part 2 - print summary statistics about small turtle
		printTurtleSteps(this.smallTurtle, "Small Turtle");

	}

}