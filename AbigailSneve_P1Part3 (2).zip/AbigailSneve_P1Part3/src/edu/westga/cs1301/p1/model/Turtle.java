package edu.westga.cs1301.p1.model;

import acm.graphics.GTurtle;

/**
 * Turtle represents a graphical turtle that can move around on the screen,
 * turn, and raise or lower its tail. When its tail is lowered, it "scratches" a
 * line on the screen that shows the path it takes.
 * 
 * @author CS 1301
 * @version Spring 2022
 */
public class Turtle extends GTurtle {

	public static final double INITIAL_TURTLE_SPEED = 0.7;
	public static final int INITIAL_SIZE = 50;
	
	private int stepCount;

	
	//TODO part 3 - add a field to store the speed of the Turtle

	/**
	 * Creates a new Turtle object of size 50 at location (25, 25).
	 * 
	 * @precondition none
	 * @postcondition isTailDown() == false AND 
	 * 				  getTurtleSize() == INITIAL_SIZE(50) AND 
	 * 				  getLocation() == (25, 25) AND
	 *                getSpeed() == INITIAL_TURTLE_SPEED(0.6)
	 * 
	 */
	public Turtle() { 
		//TODO part 3 - add a parameter for the speed of the turtle, initialize the speed field, and set the speed
		this.initialize();
	}

	/**
	 * Creates a new Turtle object at location (25, 25) with the specified size.
	 * 
	 * @precondition none
	 * @postcondition isTailDown() == false AND 
	 * 				  getTurtleSize() == size AND 
	 * 				  getLocation() == (25, 25) AND
	 *                getSpeed() == INITIAL_TURTLE_SPEED(0.6)
	 *                
	 * @param size the size of the Turtle
	 * @param set speed of turtle
	 */
	public Turtle( int size, double speed) { 
		//TODO part 3 - add a parameter for the speed of the turtle, initialize the speed field, and set the speed
		this.initialize();
		this.setSize(size);
		this.setSpeed(speed);
	}

	/**
	 * Initializes the turtle's speed, size, location, and stepCount to their default values.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	private void initialize() {
		this.setSize(Turtle.INITIAL_SIZE);
		this.setSpeed(Turtle.INITIAL_TURTLE_SPEED);
		this.setLocation(Turtle.INITIAL_SIZE / 2, Turtle.INITIAL_SIZE / 2);
		this.stepCount = 0;
	}

	/**
	 * Moves the turtle forward in its current direction by a distance equal to
	 * its own size. The turtle draws a line if its tail is down, but otherwise
	 * just moves.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public void stepForward() {
		this.forward();
		this.stepCount++;
	}

	/**
	 * Turns the turtle 30 degrees to its left.
	 *
	 * @precondition none
	 * @postcondition none
	 */
	public void turnLeft(double degrees) {
		this.left(degrees);
	}

	/**
	 * Turns the turtle given degrees to its right.
	 *
	 * @precondition none
	 * @postcondition none
	 */
	public void turnRight(double degrees) {
		this.right(degrees);
	}

	/**
	 * Drops the turtle's tail to the ground so it will draw a line when it
	 * moves.
	 * 
	 * @precondition none
	 * @postcondition isTailDown() == true
	 */
	public void lowerTail() {
		this.penDown();
	}

	/**
	 * Lifts the turtle's tail from the ground so it won't draw a line when it
	 * moves.
	 * 
	 * @precondition none
	 * @postcondition isTailDown() == false.
	 */
	public void raiseTail() {
		this.penUp();
	}
	
	/**
	 * Returns the number of steps the Turtle has take so far.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the number of steps the Turtle has take so far
	 */
	public int getStepCount() {
		return this.stepCount;
	}
	
	//TODO part 3 - add a getter deriving a statement including the turtle's size and speed.
	/**
	 * Returns the current size 
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the current size
	 */
	public int getSizeStatus() {
		return getTurtleSize();
	}
	/**
	 * Returns the current speed of the turtle
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the current speed of the turtle
	 */
	public double getSpeedStatus() {
		return getSpeed();
	}
	}
	

