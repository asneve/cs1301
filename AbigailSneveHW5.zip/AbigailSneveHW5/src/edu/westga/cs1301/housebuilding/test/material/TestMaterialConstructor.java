package edu.westga.cs1301.housebuilding.test.material;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.housebuilding.model.Material;

/**
 * Class for testing the Material class
 *
 * @author Abigail Sneve CS 1301
 * @version Spring 2022
 */
public class TestMaterialConstructor {

	@Test
	void TestNullDescription() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Material("", 35000, 0);
		});
	}

	@Test
	void TestEmptyDescription() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Material(null, 35000, 0);
		});
	}

	@Test
	void TestTQuantityIsZero() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Material("Solid", 0, 0);
		});
	}

	@Test
	void TestQuantityIsNeg() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Material("Solid", -1, 0);
		});
	}

	@Test
	void TestMinQuantity() {
		Material theMaterial = new Material("Solid", 1, 0);

		assertEquals(1, theMaterial.getQuantity(), "testing minimum");
	}

	@Test
	void TestMaxQuantity() {
		Material theMaterial = new Material("Solid", 250, 0);

		assertEquals(250, theMaterial.getQuantity(), "testing max");
	}

	@Test
	void TestTooHighOfQuantity() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Material("Solid", 251, 0);
		});
	}

	@Test
	void TestUnitCostTooHigh() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Material("Solid", 250, 371);
		});
	}

	@Test
	void TestUnitCostTooLow() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Material("Solid", 250, -1);
		});
	}

	@Test
	void TestMinUnit() {
		Material theMaterial = new Material("Solid", 1, 0);

		assertEquals(1, theMaterial.getQuantity(), "testing minimum");
	}

	@Test
	void TestMaxUnit() {
		Material theMaterial = new Material("Solid", 250, 370);

		assertEquals(250, theMaterial.getQuantity(), "testing max");
	}

}
