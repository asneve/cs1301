package edu.westga.cs1301.housebuilding.test.order;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.housebuilding.model.Order;
import edu.westga.cs1301.housebuilding.model.Material;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Class for testing the Order class
 *
 * @author Abigail Sneve CS 1301
 * @version Spring 2022
 */
public class TestOrderConstructor {
	Material oneMaterial = new Material("Solid", 1, 3);;
	Material twoMaterial = new Material("Liquid", 2, 2);;
	Material threeMaterial = new Material("Gas", 3, 1);

	@Test
	void TestNullDate() {

		assertThrows(IllegalArgumentException.class, () -> {
			new Order(null, oneMaterial, this.twoMaterial, this.threeMaterial);
		});
	}

	@Test
	void TestNullFirstMaterial() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Order(LocalDate.of(2012, 1, 12), null, this.twoMaterial, this.threeMaterial);
		});
	}

	@Test
	void TestNullSecondMaterial() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Order(LocalDate.of(2012, 1, 12), this.oneMaterial, null, this.threeMaterial);
		});
	}

	@Test
	void TestNullThirdMaterial() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Order(LocalDate.of(2012, 1, 12), this.oneMaterial, this.twoMaterial, null);
		});
	}

	@Test
	void TestFirstMaterialEqualSecond() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Order(LocalDate.of(2012, 1, 12), this.oneMaterial = this.twoMaterial, this.twoMaterial,
					this.threeMaterial);
		});
	}

	@Test
	void TestFirstMaterialEqualThird() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Order(LocalDate.of(2012, 1, 12), this.oneMaterial = this.threeMaterial, this.twoMaterial,
					this.threeMaterial);
		});
	}

	@Test
	void TestSecondMaterialEqualThird() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Order(LocalDate.of(2012, 1, 12), this.oneMaterial, this.twoMaterial = this.threeMaterial,
					this.threeMaterial);
		});
	}

	@Test
	void TestAllMaterialEqual() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Order(LocalDate.of(2012, 1, 12), this.oneMaterial = this.twoMaterial,
					this.twoMaterial = this.threeMaterial, this.threeMaterial);
		});
	}

	@Test
	void TestTheOrder() {
		Order theOrder = new Order(LocalDate.of(1999, 12, 31), this.oneMaterial, this.twoMaterial, this.threeMaterial);

		assertEquals(LocalDate.of(1999, 12, 31), theOrder.getOrderDate(), "getting order date");
		assertEquals(this.oneMaterial, theOrder.getFirstMaterial(), "getting first Material");
		assertEquals(this.twoMaterial, theOrder.getSecondMaterial(), "getting second Material");
		assertEquals(this.threeMaterial, theOrder.getThirdMaterial(), "getting third Material");
	}

}
