package edu.westga.cs1301.housebuilding.test.order;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.housebuilding.model.Material;
import edu.westga.cs1301.housebuilding.model.Order;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Class for testing the GetHighestUnitCost
 *
 * @author Abigail Sneve CS 1301
 * @version Spring 2022
 */
public class TestGetHighestUnitCost {

	@Test
	void TestFirstIsCostly() {
		Material oneMaterial = new Material("Solid", 250, 370);
		Material twoMaterial = new Material("Liquid", 2, 2);
		;
		Material threeMaterial = new Material("Gas", 3, 1);
		Order theOrder = new Order(LocalDate.of(2012, 1, 12), oneMaterial, twoMaterial, threeMaterial);
		assertEquals(370, theOrder.getHighestUnitCost(), "testing first cost the most");
	}

	@Test
	void TestSecondIsCostly() {
		Material oneMaterial = new Material("Solid", 250, 2);
		Material twoMaterial = new Material("Liquid", 2, 8);
		;
		Material threeMaterial = new Material("Gas", 3, 1);
		Order theOrder = new Order(LocalDate.of(2012, 1, 12), oneMaterial, twoMaterial, threeMaterial);
		assertEquals(8, theOrder.getHighestUnitCost(), "testing second material costs the most");
	}

	@Test
	void TestThirdIsCostly() {
		Material oneMaterial = new Material("Solid", 250, 2);
		Material twoMaterial = new Material("Liquid", 2, 8);
		;
		Material threeMaterial = new Material("Gas", 3, 9);
		Order theOrder = new Order(LocalDate.of(2012, 1, 12), oneMaterial, twoMaterial, threeMaterial);
		assertEquals(9, theOrder.getHighestUnitCost(), "testing third material costs the most");
	}

	@Test
	void TestFirstAndSecondAreCostly() {
		Material oneMaterial = new Material("Solid", 250, 8);
		Material twoMaterial = new Material("Liquid", 2, 8);
		;
		Material threeMaterial = new Material("Gas", 3, 2);
		Order theOrder = new Order(LocalDate.of(2012, 1, 12), oneMaterial, twoMaterial, threeMaterial);
		assertEquals(8, theOrder.getHighestUnitCost(), "testing first and second material costs the most");
	}

	@Test
	void TestAllAreCostly() {
		Material oneMaterial = new Material("Solid", 250, 8);
		Material twoMaterial = new Material("Liquid", 2, 8);
		;
		Material threeMaterial = new Material("Gas", 3, 8);
		Order theOrder = new Order(LocalDate.of(2012, 1, 12), oneMaterial, twoMaterial, threeMaterial);
		assertEquals(8, theOrder.getHighestUnitCost(), "testing all cost the same and its a monopoly");
	}

}
