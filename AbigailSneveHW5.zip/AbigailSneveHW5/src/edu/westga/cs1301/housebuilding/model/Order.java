package edu.westga.cs1301.housebuilding.model;

import java.time.LocalDate;

/**
 * Creates an order of materials for a new house building job.
 * 
 * @author Abigail Sneve CS 1301
 * @version Spring 2022
 */
public class Order {

	private LocalDate date;
	private Material firstMaterial;
	private Material secondMaterial;
	private Material thirdMaterial;

	/**
	 * Creates a new Order with the given materials, and a default date.
	 * 
	 * @precondition date != null && firstMaterial != null && secondMaterial != null
	 *               && thirdMaterial != null &&
	 *               !firstMaterial.getDescription().equals(secondMaterial.getDescription())
	 *               &&
	 *               !secondMaterial.getDesription().equals(thirdMaterial.getDescription())
	 *               &&
	 *               !firstMaterial.getDescription().equals(thirdMaterial.getDescription())
	 * 
	 * @postcondition getFirstMaterial() == firstMaterial && getSecondMaterial() ==
	 *                secondMaterial && getThirdMaterial() == thirdMaterial
	 * 
	 * @param date
	 *            the date of the order
	 * @param firstMaterial
	 *            first material of the order
	 * @param secondMaterial
	 *            second material of the order
	 * @param thirdMaterial
	 *            third material of the order
	 */
	public Order(LocalDate date, Material firstMaterial, Material secondMaterial, Material thirdMaterial) {

		if (date == null) {
			throw new IllegalArgumentException("Date of the order.");
		}
		if (firstMaterial == null) {
			throw new IllegalArgumentException("First material required for the order.");
		}
		if (secondMaterial == null) {
			throw new IllegalArgumentException("Second material required for the order.");
		}
		if (thirdMaterial == null) {
			throw new IllegalArgumentException("Third material required for the order.");
		}
		if (firstMaterial.getDescription().equals(secondMaterial.getDescription())
				|| secondMaterial.getDescription().equals(thirdMaterial.getDescription())
				|| firstMaterial.getDescription().equals(thirdMaterial.getDescription())) {
			throw new IllegalArgumentException("Materials must all have different descriptions.");
		}

		this.date = date;
		this.firstMaterial = firstMaterial;
		this.secondMaterial = secondMaterial;
		this.thirdMaterial = thirdMaterial;

	}

	/**
	 * Gets the highest unit cost of this order.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return highestCost highest unit cost of the three materials
	 */
	public int getHighestUnitCost() {
		int highestCost = this.firstMaterial.getUnitCost();
		int secondCost = this.secondMaterial.getUnitCost();
		int thirdCost = this.thirdMaterial.getUnitCost();

		if (highestCost < secondCost) {
			highestCost = secondCost;
		}

		if (highestCost < thirdCost) {
			highestCost = thirdCost;
		}

		return highestCost;
	}

	/**
	 * Return the first material to be ordered.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return firstMaterial the first material of this order
	 */
	public Material getFirstMaterial() {
		return this.firstMaterial;
	}

	/**
	 * Return the second material to be ordered.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return secondMaterial the second material of this order
	 */
	public Material getSecondMaterial() {
		return this.secondMaterial;
	}

	/**
	 * Return the third material to be ordered.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return thirdMaterial the third material of this order
	 */
	public Material getThirdMaterial() {
		return this.thirdMaterial;
	}

	/**
	 * Return the date of the order.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return date the date of this order
	 */
	public LocalDate getOrderDate() {
		return this.date;
	}
}
