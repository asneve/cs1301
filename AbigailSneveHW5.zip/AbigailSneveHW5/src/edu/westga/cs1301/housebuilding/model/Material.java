package edu.westga.cs1301.housebuilding.model;

/**
 * Stores information for a single Material item.
 * 
 * @author Abigail Sneve CS 1301
 * @version Spring 2022
 */
public class Material {

	private static final int MAX_UNIT_COST = 370;
	private static final int MIN_QUANTITY = 1;
	private static final int MAX_QUANTITY = 250;
	private String description;
	private int quantity;
	private int unitCost;

	/**
	 * Create a new material with the specified description, quantity, and unit
	 * cost.
	 * 
	 * @precondition description != null && !description.isEmpty() && 1 <= quantity
	 *               <= MAX_QUANTITY && 0 <= unitCost <= MAX_UNIT_COST
	 * 
	 * @postcondition getDescription().equals(description) && getQuantity() ==
	 *                quantity && getUnitCost() == unitCost
	 * 
	 * @param description description of the material
	 * @param quantity    the number of units
	 * @param unitCost    the cost per unit
	 */
	public Material(String description, int quantity, int unitCost) {

		if (description == null || description.isEmpty())
			throw new IllegalArgumentException("A valid scription must be provided.");

		if (quantity < Material.MIN_QUANTITY)
			throw new IllegalArgumentException("Quantity must be at least 1.");

		if (quantity > Material.MAX_QUANTITY)
			throw new IllegalArgumentException("Quantities larger than 250 are not accepted.");

		if (unitCost > Material.MAX_UNIT_COST)
			throw new IllegalArgumentException("Items more expensive than $370/unit are not accepted.");

		if (unitCost < 0)
			throw new IllegalArgumentException("Material cannot have a negative price.");

		this.description = description;
		this.quantity = quantity;
		this.unitCost = unitCost;
	}

	/**
	 * Return the description of the material.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return description the description of this material
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 * Return the quantity of the material.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return quantity the quantity of this material
	 */
	public int getQuantity() {
		return this.quantity;
	}

	/**
	 * Return the unit cost of the material.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return unitCost the cost per unit of this material
	 */
	public int getUnitCost() {
		return this.unitCost;
	}

}
