package edu.westga.cs1301.climate.model;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 * 
 * @author Abigail Sneve CS1301 - Spring 2022
 *
 */

public class WeatherStation {
	public static int DANGEROUSLY_HOT_TEMPERATURE = 50;
	private ArrayList<DailySummary> summary;
	String name;

	/**
	 * Creates a new WeatherStation, with no measurements, for the given name.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @param name the name of the station
	 * 
	 */

	public WeatherStation(String name) {
		this.name = name;
		this.summary = new ArrayList<DailySummary>();

	}

	/**
	 * Creates a new WeatherStation, with no measurements, for the given name.
	 * 
	 * @precondition DailySummary != null && measurement.get() does not match the
	 *               getHourOfDay() of an already-added measurement
	 * @postcondition none
	 * 
	 * @param name the name of the station
	 * 
	 */

	public void addDailySummary(DailySummary summary) {
		if (summary == null) {
			throw new IllegalArgumentException("summary can not be null");
		}

		if (hasMeasurementFor(summary.getMonth(), summary.getDay(), summary.getYear())) {
			throw new IllegalArgumentException("can not have two days with different summaries");
		}

		this.summary.add(summary);
	}

	/**
	 * Checks if this Weather Station already has an dailyMeasurment.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @param the date of the daily summary
	 * @return true if an Daily summary with the given day already exists in this
	 *         weather station; false otherwise
	 */

	public boolean hasMeasurementFor(int month, int day, int year) {

		for (DailySummary summary : this.summary) {
			if (summary.getYear() == year) {
				if (summary.getMonth() == month) {
					if (summary.getDay() == day) {
						return true;
					}
				}

			}
		}
		return false;
	}

	/**
	 * finds and returns the hottest day recorded by the WeatherStation
	 * 
	 * @precondition WeatherStation != null && measurement.get()
	 * @postcondition none
	 * 
	 * @ return hottest day
	 * 
	 */

	public LocalDate findHottestDay() {

		LocalDate hot = null;

		if (this.summary.isEmpty()) {
			hot = null;
			throw new IllegalArgumentException("summary can not be null");
		}
		int todayHi = 0;
		for (DailySummary summary : this.summary) {

			if (todayHi < summary.findHiTempInF()) {
				todayHi = summary.findHiTempInF();
				hot = summary.getDate();

			}

		}

		return hot;

	}

	/**
	 * counts the number of days this station recorded a temperature over 50 degrees
	 * Fahrenheit.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @ return count of days over 50
	 * 
	 */

	public int countDaysOver50F() {
		int count = 0;
		if (this.summary.isEmpty()) {
			throw new IllegalArgumentException("summary can not be null");
		}
		for (DailySummary summary : this.summary) {
			if (summary.wasHighTempOver(DANGEROUSLY_HOT_TEMPERATURE)) {
				count++;
			}
		}
		return count;
	}

	/**
	 * @return the dailySummary
	 */

	public ArrayList<DailySummary> getDailySummary() {
		return summary;
	}

	/**
	 * @return the station name
	 */

	public String getName() {
		return name;
	}
}
