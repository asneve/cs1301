package edu.westga.cs1301.climate.test.dailysummary;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.climate.model.DailySummary;
import edu.westga.cs1301.climate.model.HourlyMeasurement;
/**
 * Tests the getTotlaPrecipitation class.
 * 
 * @author Abigail Sneve CS1301 - Spring 2022
 *
 */

class TestGetTotalPrecipitation {
/**
 * empty DailySummary - (no HourlyMeasurements)
b. one HourlyMeasurement object in the DailySummary
c. several HourlyMeasurement objects in the DailySummary
 */

	@Test
	public void totalPrecipitationShouldBeZeroValueIfNoMeasurements() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		assertEquals(0, summary.getTotalPrecipitation());
	}
	@Test
	public void precipitationShouldBeOnlyMeasurement() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 100, 1);
		summary.addHourlyMeasurement(measurement0);
		assertEquals(1, summary.getTotalPrecipitation());
	}

	@Test
	public void multiplePrecipitation() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 10, 1);
		summary.addHourlyMeasurement(measurement0);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 100, 10);
		summary.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 20, 1);
		summary.addHourlyMeasurement(measurement2);
		assertEquals(12, summary.getTotalPrecipitation());
	}
}
