package edu.westga.cs1301.climate.test.hourlymeasurement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;

import edu.westga.cs1301.climate.model.HourlyMeasurement;

public class TestConstructor {

	@Test
	public void shouldNotAllowHourOneLessThanMinimum() {
		assertThrows(IllegalArgumentException.class, () -> {
			new HourlyMeasurement(-1, 90, 5);
		});
	}
	
	@Test
	public void shouldNotAllowHourWellBelowMinimum() {
		assertThrows(IllegalArgumentException.class, () -> {
			new HourlyMeasurement(-10, 90, 5);
		});
	}
	
	@Test
	public void shouldAllowHourAtMinimum() {
		HourlyMeasurement measurement = new HourlyMeasurement(0, 90, 5);
		assertEquals(0, measurement.getHourOfDay());
	}
	

	@Test
	public void shouldNotAllowHourOneGreaterThanMaximum() {
		assertThrows(IllegalArgumentException.class, () -> {
			new HourlyMeasurement(24, 90, 5);
		});
	}
	
	@Test
	public void shouldNotAllowHourWellAboveMaximum() {
		assertThrows(IllegalArgumentException.class, () -> {
			new HourlyMeasurement(50, 90, 5);
		});
	}
	
	@Test
	public void shouldAllowHourAtMaximum() {
		HourlyMeasurement measurement = new HourlyMeasurement(23, 90, 5);
		assertEquals(23, measurement.getHourOfDay());
	}
	
	@Test
	public void shouldNotAllowTempOneLessThanMinimum() {
		assertThrows(IllegalArgumentException.class, () -> {
			new HourlyMeasurement(12, -151, 5);
		});
	}
	
	@Test
	public void shouldNotAllowTempWellBelowMinimum() {
		assertThrows(IllegalArgumentException.class, () -> {
			new HourlyMeasurement(12, -200, 5);
		});
	}
	
	@Test
	public void shouldAllowTempAtMinimum() {
		HourlyMeasurement measurement = new HourlyMeasurement(12, -150, 5);
		assertEquals(-150, measurement.getTempInF());
	}
	
	
	@Test
	public void shouldNotAllowTempOneGreaterThanMaximum() {
		assertThrows(IllegalArgumentException.class, () -> {
			new HourlyMeasurement(12, 151, 5);
		});
	}
	
	@Test
	public void shouldNotAllowTempWellAboveMaximum() {
		assertThrows(IllegalArgumentException.class, () -> {
			new HourlyMeasurement(12, -200, 5);
		});
	}
	
	@Test
	public void shouldAllowTempAtMaximum() {
		HourlyMeasurement measurement = new HourlyMeasurement(12, 100, 5);
		assertEquals(100, measurement.getTempInF());
	}
	
	@Test
	public void shouldAllowValidNegativeTemp() {
		HourlyMeasurement measurement = new HourlyMeasurement(12, -100, 5);
		assertEquals(-100, measurement.getTempInF());
	}
	
	@Test
	public void shouldNotAllowInchesOfPrecipitationOneLessThanMinimum() {
		assertThrows(IllegalArgumentException.class, () -> {
			new HourlyMeasurement(12, 90, -1);
		});
	}
	
	@Test
	public void shouldNotAllowInchesOfPrecipitationWellBelowMinimum() {
		assertThrows(IllegalArgumentException.class, () -> {
			new HourlyMeasurement(12, 90, -10);
		});
	}
	
	@Test
	public void shouldAllowInchesOfPrecipitationAtMinimum() {
		HourlyMeasurement measurement = new HourlyMeasurement(12, 90, 0);
		assertEquals(0, measurement.getInchesOfPrecipitation());
	}
	
	@Test
	public void shouldCreateHourlyMeasurement() {
		HourlyMeasurement measurement = new HourlyMeasurement(12, 90, 5);
		assertEquals(12, measurement.getHourOfDay());
		assertEquals(90, measurement.getTempInF());
		assertEquals(5, measurement.getInchesOfPrecipitation());
	}
}
