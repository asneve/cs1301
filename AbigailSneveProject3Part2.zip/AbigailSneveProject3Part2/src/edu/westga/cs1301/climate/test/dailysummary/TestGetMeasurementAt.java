package edu.westga.cs1301.climate.test.dailysummary;

import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;

import edu.westga.cs1301.climate.model.DailySummary;
import edu.westga.cs1301.climate.model.HourlyMeasurement;

/**
 * Tests the getMeasurement class.
 * 
 * @author Abigail Sneve CS1301 - Spring 2022
 *
 */

public class TestGetMeasurementAt {

	@Test
	public void emptySummaryShouldNotHaveMeasurementForGivenHour() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		assertNull(summary.getMeasurementAt(12));
	}

	@Test
	public void shouldNotAllowBorderCaseHourOfNegativeOne() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		assertThrows(IllegalArgumentException.class, () -> {
			summary.getMeasurementAt(-1);
		});

	}

	@Test
	public void shouldNotAllowNegativeHour() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		assertThrows(IllegalArgumentException.class, () -> {
			summary.getMeasurementAt(-5);
		});

	}

	@Test
	public void shouldNotAllowBorderCaseHourOf24() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		assertThrows(IllegalArgumentException.class, () -> {
			summary.getMeasurementAt(24);
		});

	}

	@Test
	public void shouldNotAllowHourGreaterThan23() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		assertThrows(IllegalArgumentException.class, () -> {
			summary.getMeasurementAt(30);
		});
	}

	@Test
	public void shouldGetMeasurementAtHourZero() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement1 = new HourlyMeasurement(0, 50, 1);
		summary.addHourlyMeasurement(measurement1);
		assertEquals(measurement1, summary.getMeasurementAt(0));
	}

	@Test
	public void shouldGetMeasurementAtHour23() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement1 = new HourlyMeasurement(23, 50, 1);
		summary.addHourlyMeasurement(measurement1);
		assertEquals(measurement1, summary.getMeasurementAt(23));
	}

	@Test
	public void shouldGetFirstMeasurment() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement1 = new HourlyMeasurement(10, 50, 1);
		summary.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(11, 50, 1);
		summary.addHourlyMeasurement(measurement2);
		HourlyMeasurement measurement3 = new HourlyMeasurement(12, 50, 1);
		summary.addHourlyMeasurement(measurement3);
		assertEquals(measurement1, summary.getMeasurementAt(10));
	}

	@Test
	public void shouldGetLastMeasurment() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement1 = new HourlyMeasurement(10, 50, 1);
		summary.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(11, 50, 1);
		summary.addHourlyMeasurement(measurement2);
		HourlyMeasurement measurement3 = new HourlyMeasurement(12, 50, 1);
		summary.addHourlyMeasurement(measurement3);
		assertEquals(measurement3, summary.getMeasurementAt(12));
	}

	@Test
	public void shouldGetMiddleMeasurment() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement1 = new HourlyMeasurement(10, 50, 1);
		summary.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(11, 50, 1);
		summary.addHourlyMeasurement(measurement2);
		HourlyMeasurement measurement3 = new HourlyMeasurement(12, 50, 1);
		summary.addHourlyMeasurement(measurement3);
		assertEquals(measurement2, summary.getMeasurementAt(11));
	}

	@Test
	public void shouldNotFindDesiredMeasurement() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement1 = new HourlyMeasurement(10, 50, 1);
		summary.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(11, 50, 1);
		summary.addHourlyMeasurement(measurement2);
		HourlyMeasurement measurement3 = new HourlyMeasurement(12, 50, 1);
		summary.addHourlyMeasurement(measurement3);
		assertNull(summary.getMeasurementAt(15));
	}
}
