package edu.westga.cs1301.climate.test.weatherstation;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.climate.model.DailySummary;
import edu.westga.cs1301.climate.model.WeatherStation;

class TestConstructor {

	/*
	 * Tests the dailySummary constructor
	 * 
	 * @author Abigail Sneve CS1301 - Spring 2022
	 *
	 */

	@Test
	public void shouldHaveNoMeasurementsInWeatherStation() {
		WeatherStation station = new WeatherStation("North");
		assertTrue(station.getDailySummary().isEmpty());
		assertEquals("North", station.getName());
	}
}
