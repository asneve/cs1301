package edu.westga.cs1301.climate.test.weatherstation;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.climate.model.DailySummary;
import edu.westga.cs1301.climate.model.HourlyMeasurement;
import edu.westga.cs1301.climate.model.WeatherStation;
/**
 * Tests the hottest day
 * 
 * @author Abigail Sneve  CS1301 - Spring 2022
 *
 *
 */

class TestFindHottestDay {


	@Test
	public void hottestDayIsNull() {
	
		WeatherStation station = new WeatherStation("North");
		

		assertThrows(IllegalArgumentException.class, () -> {
			station.findHottestDay();
		});
	}

	@Test
	public void hiTempShouldBeFirstMeasurement() {
		WeatherStation station = new WeatherStation("North");
		DailySummary summary1 = new DailySummary(1, 1, 2017);
		DailySummary summary2 = new DailySummary(2, 1, 2017);
		DailySummary summary3 = new DailySummary(3, 1, 2017);
		station.addDailySummary(summary3);
		station.addDailySummary(summary2);
		station.addDailySummary(summary1);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 100, 1);
		summary1.addHourlyMeasurement(measurement0);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 10, 10);
		summary2.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 20, 1);
		summary3.addHourlyMeasurement(measurement2);
		assertEquals(summary1.getDate(), station.findHottestDay());
	}

	@Test
	public void hiTempShouldBeLastMeasurement() {
		WeatherStation station = new WeatherStation("North");
		DailySummary summary1 = new DailySummary(1, 2, 2017);
		DailySummary summary2 = new DailySummary(2, 3, 2018);
		DailySummary summary3 = new DailySummary(3, 4, 2019);
		station.addDailySummary(summary3);
		station.addDailySummary(summary2);
		station.addDailySummary(summary1);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 10, 1);
		summary1.addHourlyMeasurement(measurement0);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 20, 10);
		summary2.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 100, 1);
		summary3.addHourlyMeasurement(measurement2);
		assertEquals(summary3.getDate(), station.findHottestDay());
	}

	@Test
	public void hiTempShouldBeMiddleMeasurement() {
		WeatherStation station = new WeatherStation("North");
		DailySummary summary1 = new DailySummary(1, 1, 2017);
		DailySummary summary2 = new DailySummary(2, 1, 2017);
		DailySummary summary3 = new DailySummary(3, 1, 2017);
		station.addDailySummary(summary3);
		station.addDailySummary(summary2);
		station.addDailySummary(summary1);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 10, 1);
		summary1.addHourlyMeasurement(measurement0);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 100, 10);
		summary2.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 20, 1);
		summary3.addHourlyMeasurement(measurement2);
		assertEquals(summary2.getDate(), station.findHottestDay());
	}

}
