package edu.westga.cs1301.climate.test.dailysummary;

import static org.junit.Assert.*;

import org.junit.Test;

import edu.westga.cs1301.climate.model.DailySummary;
import edu.westga.cs1301.climate.model.HourlyMeasurement;

public class TestConstructor {
	/*
	 * Tests the dailySummary constructor
	 * 
	 * @author Abigail Sneve CS1301 - Spring 2022
	 *
	 */

	@Test
	public void shouldHaveNoMeasurementsInNewDailySummary() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		assertTrue(summary.getHourlyMeasurements().isEmpty());
	}
}
