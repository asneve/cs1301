package edu.westga.cs1301.climate.test.dailysummary;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;

import edu.westga.cs1301.climate.model.DailySummary;
import edu.westga.cs1301.climate.model.HourlyMeasurement;

public class TestFindHiTempInF {
	/**
	 * Tests the findHiTempF class.
	 * 
	 * @author Abigail Sneve CS1301 - Spring 2022
	 *
	 */

	@Test
	public void hiTempShouldBeIntegerMinValueIfNoMeasurements() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		assertEquals(Integer.MIN_VALUE, summary.findHiTempInF());
	}

	@Test
	public void hiTempShouldBeOnlyMeasurement() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 100, 1);
		summary.addHourlyMeasurement(measurement0);
		assertEquals(100, summary.findHiTempInF());
	}

	@Test
	public void hiTempShouldBeFirstMeasurement() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 100, 1);
		summary.addHourlyMeasurement(measurement0);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 10, 10);
		summary.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 20, 1);
		summary.addHourlyMeasurement(measurement2);
		assertEquals(100, summary.findHiTempInF());
	}

	@Test
	public void hiTempShouldBeLastMeasurement() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 20, 1);
		summary.addHourlyMeasurement(measurement0);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 10, 10);
		summary.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 100, 1);
		summary.addHourlyMeasurement(measurement2);
		assertEquals(100, summary.findHiTempInF());
	}

	@Test
	public void hiTempShouldBeMiddleMeasurement() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 10, 1);
		summary.addHourlyMeasurement(measurement0);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 100, 10);
		summary.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 20, 1);
		summary.addHourlyMeasurement(measurement2);
		assertEquals(100, summary.findHiTempInF());
	}
}
