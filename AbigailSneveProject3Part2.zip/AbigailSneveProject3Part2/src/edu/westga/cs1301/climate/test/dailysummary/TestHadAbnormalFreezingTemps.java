package edu.westga.cs1301.climate.test.dailysummary;

import static org.junit.jupiter.api.Assertions.*;
/**
 * Tests the abnormal temps class.
 * 
 * @author Abigail Sneve CS1301 - Spring 2022
 *
 */

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.climate.model.DailySummary;
import edu.westga.cs1301.climate.model.HourlyMeasurement;

class TestHadAbnormalFreezingTemps {
	/**
	 * empty DailySummary - (no HourlyMeasurements) b. single measurement one degree
	 * below abnormal freezing c. single measurement at abnormal freezing d. single
	 * measurement one degree above abnormal freezing e. several measurements, first
	 * is below abnormal freezing f. several measurements, last is below abnormal
	 * freezing g. several measurements, middle is below abnormal freezing h.
	 * several measurements, none below abnormal freezing i. several measurements,
	 * more than one, but not all below abnormal freezing
	 */

	@Test
	public void noHourlyMeasurementsToTestAbnormalTemps() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		assertEquals(false, summary.hadAbnormalFreezingTemps());
	}

	@Test
	public void oneMeasurmentToTestAtAbnormalTemps() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, -55, 1);
		summary.addHourlyMeasurement(measurement0);
		assertEquals(true, summary.hadAbnormalFreezingTemps());
	}

	@Test
	public void oneDegreeAboveAbnormalTemps() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, -39, 1);
		summary.addHourlyMeasurement(measurement0);
		assertEquals(false, summary.hadAbnormalFreezingTemps());
	}

	@Test
	public void firstMeasurmentToTestAtAbnormalTemps() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, -55, 1);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 20, 1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 10, 1);
		summary.addHourlyMeasurement(measurement0);
		summary.addHourlyMeasurement(measurement1);
		summary.addHourlyMeasurement(measurement2);
		assertEquals(true, summary.hadAbnormalFreezingTemps());
	}

	@Test
	public void lastMeasurmentToTestAtAbnormalTemps() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 10, 1);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 20, 1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, -55, 1);
		summary.addHourlyMeasurement(measurement0);
		summary.addHourlyMeasurement(measurement1);
		summary.addHourlyMeasurement(measurement2);
		assertEquals(true, summary.hadAbnormalFreezingTemps());
	}

	@Test
	public void middleMeasurmentToTestAtAbnormalTemps() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 10, 1);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, -55, 1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 20, 1);
		summary.addHourlyMeasurement(measurement0);
		summary.addHourlyMeasurement(measurement1);
		summary.addHourlyMeasurement(measurement2);
		assertEquals(true, summary.hadAbnormalFreezingTemps());
	}

	@Test
	public void noneMeasurmentToTestAtAbnormalTemps() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 10, 1);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 30, 1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 20, 1);
		summary.addHourlyMeasurement(measurement0);
		summary.addHourlyMeasurement(measurement1);
		summary.addHourlyMeasurement(measurement2);
		assertEquals(false, summary.hadAbnormalFreezingTemps());
	}

	@Test
	public void multipleMeasurmentToTestAtAbnormalTemps() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, -55, 1);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, -56, 1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 20, 1);
		summary.addHourlyMeasurement(measurement0);
		summary.addHourlyMeasurement(measurement1);
		summary.addHourlyMeasurement(measurement2);
		assertEquals(true, summary.hadAbnormalFreezingTemps());
	}
}
