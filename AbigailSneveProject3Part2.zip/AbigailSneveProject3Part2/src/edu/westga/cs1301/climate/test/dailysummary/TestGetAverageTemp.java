package edu.westga.cs1301.climate.test.dailysummary;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;

import edu.westga.cs1301.climate.model.DailySummary;
import edu.westga.cs1301.climate.model.HourlyMeasurement;

/**
 * Tests the getAverageTemp class.
 * 
 * @author Abigail Sneve CS1301 - Spring 2022
 *
 */
public class TestGetAverageTemp {

	@Test
	public void shouldGetSentinelWhenNoHourlyMeasurements() {
		DailySummary summary = new DailySummary(9, 15, 2017);
		assertEquals(Double.MIN_VALUE, summary.getAverageTemp(), 0.01);
	}

	@Test
	public void shouldGetAverageWhenOnlyHasOneMeasurement() {
		DailySummary summary = new DailySummary(9, 15, 2017);
		HourlyMeasurement measurement1 = new HourlyMeasurement(12, 80, 1);
		summary.addHourlyMeasurement(measurement1);
		assertEquals(80, summary.getAverageTemp(), 0.01);
	}

	@Test
	public void shouldGetAverageWhenHasManyMeasurements() {
		DailySummary summary = new DailySummary(9, 15, 2017);
		HourlyMeasurement measurement1 = new HourlyMeasurement(12, 80, 1);
		summary.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(13, 90, 1);
		summary.addHourlyMeasurement(measurement2);
		HourlyMeasurement measurement3 = new HourlyMeasurement(14, 50, 1);
		summary.addHourlyMeasurement(measurement3);
		assertEquals(73.33, summary.getAverageTemp(), 0.01);
	}
}
