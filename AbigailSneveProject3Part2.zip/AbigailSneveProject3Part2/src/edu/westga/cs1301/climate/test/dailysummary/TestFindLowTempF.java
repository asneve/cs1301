package edu.westga.cs1301.climate.test.dailysummary;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.climate.model.DailySummary;
import edu.westga.cs1301.climate.model.HourlyMeasurement;

/**
 * Tests the findLowTempInF class.
 * 
 * @author Abigail Sneve CS1301 - Spring 2022
 *
 */

class TestFindLowTempF {

	@Test
	public void lowTempShouldBeIntegerMinValueIfNoMeasurements() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		assertEquals(Integer.MIN_VALUE, summary.findLowTempInF());
	}

	@Test
	public void lowTempShouldBeOnlyMeasurement() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 100, 1);
		summary.addHourlyMeasurement(measurement0);
		assertEquals(100, summary.findLowTempInF());
	}

	@Test
	public void lowTempShouldBeFirstMeasurement() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 10, 1);
		summary.addHourlyMeasurement(measurement0);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 100, 10);
		summary.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 20, 1);
		summary.addHourlyMeasurement(measurement2);
		assertEquals(100, summary.findLowTempInF());
	}

	@Test
	public void lowTempShouldBeLastMeasurement() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 25, 1);
		summary.addHourlyMeasurement(measurement0);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 100, 10);
		summary.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 10, 1);
		summary.addHourlyMeasurement(measurement2);
		assertEquals(100, summary.findLowTempInF());
	}

	@Test
	public void lowTempShouldBeMiddleMeasurement() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 100, 1);
		summary.addHourlyMeasurement(measurement0);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 10, 10);
		summary.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 20, 1);
		summary.addHourlyMeasurement(measurement2);
		assertEquals(100, summary.findLowTempInF());
	}
}
