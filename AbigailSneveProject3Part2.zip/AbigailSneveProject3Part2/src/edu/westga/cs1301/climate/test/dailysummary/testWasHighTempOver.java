package edu.westga.cs1301.climate.test.dailysummary;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.climate.model.DailySummary;
import edu.westga.cs1301.climate.model.HourlyMeasurement;

class testWasHighTempOver {
	/**
	 * Tests the HightempOver class.
	 * 
	 * @author Abigail Sneve CS1301 - Spring 2022
	 *
	 */

	@Test
	public void noHourlyMeasurementsToTestThreshold() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		assertEquals(false, summary.wasHighTempOver(85));
	}

	@Test
	public void oneBelowMin() {
		assertThrows(IllegalArgumentException.class, () -> {
			new HourlyMeasurement(12, HourlyMeasurement.FAHRENHEIT_MIN - 1, 0);
		});
	}

	@Test
	public void oneAboveMin() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, HourlyMeasurement.FAHRENHEIT_MIN + 1, 1);
		summary.addHourlyMeasurement(measurement0);
		assertEquals(true, summary.wasHighTempOver(HourlyMeasurement.FAHRENHEIT_MIN + 1));

	}

	@Test
	public void isTheMin() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, HourlyMeasurement.FAHRENHEIT_MIN, 1);
		summary.addHourlyMeasurement(measurement0);
		assertThrows(IllegalArgumentException.class, () -> {
			summary.wasHighTempOver(HourlyMeasurement.FAHRENHEIT_MIN);
		});
	}

	@Test
	public void oneMeasurmentToTestAtTheshold() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 85, 1);
		summary.addHourlyMeasurement(measurement0);
		assertEquals(true, summary.wasHighTempOver(85));
	}

	@Test
	public void oneDegreeBelowTheshold() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 84, 1);
		summary.addHourlyMeasurement(measurement0);
		assertEquals(false, summary.wasHighTempOver(85));
	}

	@Test
	public void noneMeasurmentToTestAtThreshold() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 10, 1);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 30, 1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 20, 1);
		summary.addHourlyMeasurement(measurement0);
		summary.addHourlyMeasurement(measurement1);
		summary.addHourlyMeasurement(measurement2);
		assertEquals(false, summary.wasHighTempOver(85));
	}

	@Test
	public void multipleMeasurmentToTestAtThreshold() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 85, 1);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 85, 1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 20, 1);
		summary.addHourlyMeasurement(measurement0);
		summary.addHourlyMeasurement(measurement1);
		summary.addHourlyMeasurement(measurement2);
		assertEquals(true, summary.wasHighTempOver(85));
	}

	@Test
	public void allMeasurmentToTestAtThreshold() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 85, 1);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 85, 1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 85, 1);
		summary.addHourlyMeasurement(measurement0);
		summary.addHourlyMeasurement(measurement1);
		summary.addHourlyMeasurement(measurement2);
		assertEquals(true, summary.wasHighTempOver(85));
	}
}
