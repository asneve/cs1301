package edu.westga.cs1301.climate.test.dailysummary;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.climate.model.DailySummary;
import edu.westga.cs1301.climate.model.HourlyMeasurement;

/**
 * Tests the hasMeasurement class.
 * 
 * @author Abigail Sneve CS1301 - Spring 2022
 *
 */
public class TestHasMeasurementFor {

	@Test
	public void shouldNotAllowBorderCaseHourOfNegativeOne() {
		DailySummary summary = new DailySummary(9, 15, 2017);
		assertThrows(IllegalArgumentException.class, () -> {
			summary.hasMeasurementFor(-1);
		});
		
	}
	
	@Test
	public void shouldNotAllowNegativeHour() {
		DailySummary summary = new DailySummary(9, 15, 2017);
		assertThrows(IllegalArgumentException.class, () -> {
			summary.hasMeasurementFor(-5);
		});
	}
	
	@Test
	public void shouldNotAllowBorderCaseHourOf24() {
		DailySummary summary = new DailySummary(9, 15, 2017);
		assertThrows(IllegalArgumentException.class, () -> {
			summary.hasMeasurementFor(24);
		});
		
	}
	
	@Test
	public void shouldNotAllowHourGreaterThan23() {
		DailySummary summary = new DailySummary(9, 15, 2017);
		assertThrows(IllegalArgumentException.class, () -> {
			summary.hasMeasurementFor(30);
		});
	}
	
	@Test
	public void shouldHaveMeasurementAtBorderCaseOfHourZero() {
		DailySummary summary = new DailySummary(9, 15, 2017);
		HourlyMeasurement measurement = new HourlyMeasurement(0, 80, 1);
		summary.addHourlyMeasurement(measurement);
		assertTrue(summary.hasMeasurementFor(0));
	}
	
	@Test
	public void shouldHaveMeasurementAtBorderCaseOfHour23() {
		DailySummary summary = new DailySummary(9, 15, 2017);
		HourlyMeasurement measurement = new HourlyMeasurement(23, 80, 1);
		summary.addHourlyMeasurement(measurement);
		assertTrue(summary.hasMeasurementFor(23));
	}

	@Test
	public void shouldHaveSingleMeasurement() {
		DailySummary summary = new DailySummary(9, 15, 2017);
		HourlyMeasurement measurement = new HourlyMeasurement(12, 80, 1);
		summary.addHourlyMeasurement(measurement);
		assertTrue(summary.hasMeasurementFor(12));
	}
	
	@Test
	public void emptySummaryShouldNotHaveMeasurement() {
		DailySummary summary = new DailySummary(9, 15, 2017);
		assertFalse(summary.hasMeasurementFor(12));
	}
	
	@Test
	public void shouldHaveFirstMeasurement() {
		DailySummary summary = new DailySummary(9, 15, 2017);
		HourlyMeasurement measurement1 = new HourlyMeasurement(12, 80, 1);
		summary.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(4, 80, 1);
		summary.addHourlyMeasurement(measurement2);
		HourlyMeasurement measurement3 = new HourlyMeasurement(15, 80, 1);
		summary.addHourlyMeasurement(measurement3);
		assertTrue(summary.hasMeasurementFor(12));
	}
	
	@Test
	public void shouldHaveMiddleMeasurement() {
		DailySummary summary = new DailySummary(9, 15, 2017);
		HourlyMeasurement measurement1 = new HourlyMeasurement(12, 80, 1);
		summary.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(4, 80, 1);
		summary.addHourlyMeasurement(measurement2);
		HourlyMeasurement measurement3 = new HourlyMeasurement(15, 80, 1);
		summary.addHourlyMeasurement(measurement3);
		assertTrue(summary.hasMeasurementFor(4));
	}
	
	@Test
	public void shouldHaveLastMeasurement() {
		DailySummary summary = new DailySummary(9, 15, 2017);
		HourlyMeasurement measurement1 = new HourlyMeasurement(12, 80, 1);
		summary.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(4, 80, 1);
		summary.addHourlyMeasurement(measurement2);
		HourlyMeasurement measurement3 = new HourlyMeasurement(15, 80, 1);
		summary.addHourlyMeasurement(measurement3);
		assertTrue(summary.hasMeasurementFor(15));
	}
	
	@Test
	public void shouldNotHaveMeasurement() {
		DailySummary summary = new DailySummary(9, 15, 2017);
		HourlyMeasurement measurement1 = new HourlyMeasurement(12, 80, 1);
		summary.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(4, 80, 1);
		summary.addHourlyMeasurement(measurement2);
		HourlyMeasurement measurement3 = new HourlyMeasurement(15, 80, 1);
		summary.addHourlyMeasurement(measurement3);
		assertFalse(summary.hasMeasurementFor(10));
	}
}
