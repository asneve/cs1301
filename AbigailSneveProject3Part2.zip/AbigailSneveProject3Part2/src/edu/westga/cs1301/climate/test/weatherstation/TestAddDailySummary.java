package edu.westga.cs1301.climate.test.weatherstation;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.climate.model.DailySummary;

import edu.westga.cs1301.climate.model.WeatherStation;

class TestAddDailySummary {

	/**
	 * Tests the addHourlyMeasurement class
	 * 
	 * @author Abigail Sneve CS1301 - Spring 2022
	 *
	 */

	@Test
	public void shouldAddOneMeasurment() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		WeatherStation station = new WeatherStation("North");
		station.addDailySummary(summary);

		ArrayList<DailySummary> sum = station.getDailySummary();
		assertEquals(summary, sum.get(0));
	}

	@Test
	public void shouldAddManyMeasurements() {
		DailySummary summary1 = new DailySummary(1, 1, 2017);
		DailySummary summary2 = new DailySummary(2, 1, 2017);
		DailySummary summary3 = new DailySummary(3, 1, 2017);
		WeatherStation station = new WeatherStation("North");
		station.addDailySummary(summary1);
		station.addDailySummary(summary2);
		station.addDailySummary(summary3);

		ArrayList<DailySummary> sum = station.getDailySummary();
		assertEquals(summary1, sum.get(0));
		assertEquals(summary2, sum.get(1));
		assertEquals(summary3, sum.get(2));
	}

	@Test
	public void shouldNotAddIfDayAlreadyInStation() {
		DailySummary summary1 = new DailySummary(3, 1, 2017);
		DailySummary summary2 = new DailySummary(3, 1, 2017);
		WeatherStation station = new WeatherStation("North");
		station.addDailySummary(summary1);

		assertThrows(IllegalArgumentException.class, () -> {
			station.addDailySummary(summary2);
		});

	}

	@Test
	public void shouldNotAddNull() {
		WeatherStation station = new WeatherStation("North");
		assertThrows(IllegalArgumentException.class, () -> {
			station.addDailySummary(null);
		});

	}

	@Test
	public void shouldNotAddIfAllHoursInSummary() {
		WeatherStation station = new WeatherStation("North");
		for (int i = 1; i <= 12; i++) {
			DailySummary summary2 = new DailySummary(i, 1, 2017);
			station.addDailySummary(summary2);
		}

		DailySummary dud = new DailySummary(11, 1, 2017);

		assertThrows(IllegalArgumentException.class, () -> {
			station.addDailySummary(dud);
		});

	}

}
