package edu.westga.cs1301.climate.test.weatherstation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.climate.model.DailySummary;
import edu.westga.cs1301.climate.model.HourlyMeasurement;
import edu.westga.cs1301.climate.model.WeatherStation;

class TestCountDaysOver50 {
	/**
	 * Tests the temps if at 50 and gives a count
	 * 
	 * @author Abigail Sneve CS1301 - Spring 2022
	 *
	 *
	 */
	@Test
	public void is50Null() {

		WeatherStation station = new WeatherStation("North");
		assertThrows(IllegalArgumentException.class, () -> {
			station.countDaysOver50F();
		});
	}

	@Test
	public void oneDayUnder50() {

		WeatherStation station = new WeatherStation("North");
		DailySummary summary1 = new DailySummary(1, 1, 2017);
		station.addDailySummary(summary1);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 40, 1);
		summary1.addHourlyMeasurement(measurement0);
		assertEquals(0, station.countDaysOver50F());
	}

	@Test
	public void oneDayAt50() {

		WeatherStation station = new WeatherStation("North");
		DailySummary summary1 = new DailySummary(1, 1, 2017);
		station.addDailySummary(summary1);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 50, 1);
		summary1.addHourlyMeasurement(measurement0);
		assertEquals(1, station.countDaysOver50F());
	}

	@Test
	public void multiOver50() {
		WeatherStation station = new WeatherStation("North");
		DailySummary summary1 = new DailySummary(1, 1, 2017);
		DailySummary summary2 = new DailySummary(2, 1, 2017);
		DailySummary summary3 = new DailySummary(3, 1, 2017);
		station.addDailySummary(summary3);
		station.addDailySummary(summary2);
		station.addDailySummary(summary1);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 100, 1);
		summary1.addHourlyMeasurement(measurement0);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 60, 10);
		summary2.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 70, 1);
		summary3.addHourlyMeasurement(measurement2);
		assertEquals(3, station.countDaysOver50F());
	}

	@Test
	public void multiUnder50() {
		WeatherStation station = new WeatherStation("North");
		DailySummary summary1 = new DailySummary(1, 1, 2017);
		DailySummary summary2 = new DailySummary(2, 1, 2017);
		DailySummary summary3 = new DailySummary(3, 1, 2017);
		station.addDailySummary(summary3);
		station.addDailySummary(summary2);
		station.addDailySummary(summary1);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 20, 1);
		summary1.addHourlyMeasurement(measurement0);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 6, 10);
		summary2.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 7, 1);
		summary3.addHourlyMeasurement(measurement2);
		assertEquals(0, station.countDaysOver50F());
	}

	@Test
	public void multiOverAndUnder50() {
		WeatherStation station = new WeatherStation("North");
		DailySummary summary1 = new DailySummary(1, 1, 2017);
		DailySummary summary2 = new DailySummary(2, 1, 2017);
		DailySummary summary3 = new DailySummary(3, 1, 2017);
		station.addDailySummary(summary3);
		station.addDailySummary(summary2);
		station.addDailySummary(summary1);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 100, 1);
		summary1.addHourlyMeasurement(measurement0);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 6, 10);
		summary2.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 70, 1);
		summary3.addHourlyMeasurement(measurement2);
		assertEquals(2, station.countDaysOver50F());
	}

}
