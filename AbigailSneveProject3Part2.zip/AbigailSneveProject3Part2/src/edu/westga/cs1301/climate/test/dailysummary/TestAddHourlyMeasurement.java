package edu.westga.cs1301.climate.test.dailysummary;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import edu.westga.cs1301.climate.model.DailySummary;
import edu.westga.cs1301.climate.model.HourlyMeasurement;

public class TestAddHourlyMeasurement {
	/**
	 * Tests the addHourlyMeasurement class
	 * 
	 * @author Abigail Sneve CS1301 - Spring 2022
	 *
	 */

	@Test
	public void shouldAddOneMeasurment() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement = new HourlyMeasurement(12, 90, 1);
		summary.addHourlyMeasurement(measurement);
		assertEquals(1, summary.getNumberOfMeasurements());
		ArrayList<HourlyMeasurement> measurements = summary.getHourlyMeasurements();
		assertEquals(measurement, measurements.get(0));
	}

	@Test
	public void shouldAddManyMeasurements() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 90, 1);
		summary.addHourlyMeasurement(measurement0);
		HourlyMeasurement measurement1 = new HourlyMeasurement(13, 80, 10);
		summary.addHourlyMeasurement(measurement1);
		HourlyMeasurement measurement2 = new HourlyMeasurement(14, 70, 1);
		summary.addHourlyMeasurement(measurement2);
		assertEquals(3, summary.getNumberOfMeasurements());
		ArrayList<HourlyMeasurement> measurements = summary.getHourlyMeasurements();
		assertEquals(measurement0, measurements.get(0));
		assertEquals(measurement1, measurements.get(1));
		assertEquals(measurement2, measurements.get(2));
	}

	@Test
	public void shouldNotAddIfHourAlreadyInSummary() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		HourlyMeasurement measurement0 = new HourlyMeasurement(12, 90, 1);
		summary.addHourlyMeasurement(measurement0);
		HourlyMeasurement measurement1 = new HourlyMeasurement(12, 80, 10);

		assertThrows(IllegalArgumentException.class, () -> {
			summary.addHourlyMeasurement(measurement1);
		});

	}

	@Test
	public void shouldNotAddNull() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		assertThrows(IllegalArgumentException.class, () -> {
			summary.addHourlyMeasurement(null);
		});

	}

	@Test
	public void shouldNotAddIfAllHoursInSummary() {
		DailySummary summary = new DailySummary(1, 1, 2017);
		for (int i = 0; i <= 23; i++) {
			HourlyMeasurement measurement = new HourlyMeasurement(i, 90, 1);
			summary.addHourlyMeasurement(measurement);
		}

		HourlyMeasurement dud = new HourlyMeasurement(12, 90, 1);

		assertThrows(IllegalArgumentException.class, () -> {
			summary.addHourlyMeasurement(dud);
		});

	}

}
