package edu.westga.cs1301.sketch.tests.turtle;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import edu.westga.cs1301.sketch.model.Turtle;
import edu.westga.cs1301.sketch.view.Gui;

class TestStepForward {	
	private static Gui gui;

	@BeforeAll
	static void setup() {
		TestStepForward.gui = new Gui();
	}

	@Test
	void testSingleStepWithNoParameter() {
		Turtle turtle = new Turtle("test");
		turtle.setSpeed(1.0);
		
		turtle.stepForward();
		
		assertEquals(50, turtle.getPixelsMoved(), "checking number of pixels moved");
	}

	@Test
	void testMultipleStepsWithNoParameter() {
		Turtle turtle = new Turtle("test", 75);
		turtle.setSpeed(1.0);
		
		turtle.stepForward();
		turtle.stepForward();
		
		assertEquals(150, turtle.getPixelsMoved(), "checking number of pixels moved");
	}

	@Test
	void testSingleStepWithSingleParameter() {
		Turtle turtle = new Turtle("test", 100);
		turtle.setSpeed(1.0);
		
		turtle.stepForward(1);

		assertEquals(100, turtle.getPixelsMoved(), "checking number of pixels moved");
	}

	@Test
	void testMultipleStepsWithSingleParameter() {
		Turtle turtle = new Turtle("test");
		turtle.setSpeed(1.0);
		
		turtle.stepForward(3);

		assertEquals(150, turtle.getPixelsMoved(), "checking number of pixels moved");
	}

}
