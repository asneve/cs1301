package edu.westga.cs1301.sketch.tests.turtle;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import edu.westga.cs1301.sketch.model.Turtle;
import edu.westga.cs1301.sketch.view.Gui;

class TestTurnRight {	
	private static Gui gui;

	@BeforeAll
	static void setup() {
		TestTurnRight.gui = new Gui();
	}

	@Test
	void testSingleTurnWithNoParameter() {
		Turtle turtle = new Turtle("test");
		turtle.setSpeed(1.0);
		
		turtle.turnRight();
		
		assertEquals(15, turtle.getDegreesTurned(), "checking number of degrees turned");
	}

	@Test
	void testMultipleTurnsWithNoParameter() {
		Turtle turtle = new Turtle("test");
		turtle.setSpeed(1.0);

		turtle.turnRight();
		turtle.turnRight();

		assertEquals(30, turtle.getDegreesTurned(), "checking number of degrees turned");
	}

	@Test
	void testSingleTurnWithSingleParameter() {
		Turtle turtle = new Turtle("test");
		turtle.setSpeed(1.0);
		
		turtle.turnRight(1);

		assertEquals(15, turtle.getDegreesTurned(), "checking number of degrees turned");
	}

	@Test
	void testMultipleTurnsWithSingleParameter() {
		Turtle turtle = new Turtle("test");
		turtle.setSpeed(1.0);
		
		turtle.turnRight(3);

		assertEquals(45, turtle.getDegreesTurned(), "checking number of degrees turned");
	}

}
