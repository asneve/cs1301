package edu.westga.cs1301.sketch.model;

import acm.graphics.GTurtle;

/**
 * Turtle represents a graphical turtle that can move around on the screen,
 * turn, and raise or lower its tail. When its tail is lowered, it "scratches" a
 * line on the screen that shows the path it takes.
 * 
 * @author CS 1301
 * @version Spring 2022
 */
public class Turtle extends GTurtle {

	public static final double INITIAL_TURTLE_SPEED = 0.8;
	public static final int INITIAL_TURTLE_SIZE = 50;

	private int pixelsMoved;
	private int degreesTurned;
	private String name;
	private Object stepCount;

	/**
	 * Creates a new Turtle object of size 50 at location 25, 25.
	 * 
	 * @precondition name != null
	 * @postcondition isTailDown() == false AND getTurtleSize() == INITIAL_SIZE(50)
	 *                AND getLocation() == (25, 25) AND getSpeed() ==
	 *                INITIAL_TURTLE_SPEED(0.8) AND getName() == name
	 * 
	 * @param name the name of the turtle
	 */
	public Turtle(String name) {
		this(name, Turtle.INITIAL_TURTLE_SIZE);
	}

	/**
	 * Creates a new Turtle object of specified size at location 25, 25.
	 * 
	 * @precondition name != null AND size > 0
	 * @postcondition isTailDown() == false AND getTurtleSize() == size AND
	 *                getLocation() == (25, 25) AND getSpeed() ==
	 *                INITIAL_TURTLE_SPEED(0.8) AND getName() == name
	 * 
	 * @param size the size of the turtle
	 * @param name the name of the turtle
	 */
	public Turtle(String name, int size) {
		this.setSize(size);
		this.setSpeed(Turtle.INITIAL_TURTLE_SPEED);
		this.setLocation(25, 25);
		this.pixelsMoved = 0;
		this.degreesTurned = 0;
		this.name = name;
	}

	/**
	 * Moves the turtle forward in its current direction by a distance equal to its
	 * own size. The turtle draws a line if its tail is down, but otherwise just
	 * moves.
	 * 
	 * @precondition none
	 * @postcondition getPixelsMoved() == (getTurnsMade()@pre + getTurtleSize())
	 */
	public void stepForward() {
		this.forward();
		this.pixelsMoved += this.getTurtleSize();
	}

	/**
	 * Moves the turtle forward in its current direction by a distance equal to its
	 * own size for the number of specified steps. The turtle draws a line if its
	 * tail is down, but otherwise just moves.
	 * 
	 * @precondition stepCount >= 0
	 * @postcondition getPixelsMoved() == (getTurnsMade()@pre + (stepCount *
	 *                getTurtleSize()))
	 * 
	 * @param stepCount count of the number of steps to take
	 */
	// TODO Step 1
public int stepForward (int stepCount) {
	this.forward(stepCount * getTurtleSize());
	pixelsMoved =  (stepCount * getTurtleSize());
	return getPixelsMoved();
	
		
	}
	



	/**
	 * Turns the turtle 15 degrees to its left.
	 *
	 * @precondition none
	 * @postcondition getDegreesTurned() == (getDegreesTurned()@pre + 15)
	 */
	public void turnLeft() {
		this.left(15.0);
		this.degreesTurned += 15;
	}

	/**
	 * Turns the turtle the specified number of turns (each 15 degrees) to its left.
	 *
	 * @precondition turnCount >= 0
	 * @postcondition getDegreesTurned() == (getDegreesTurned()@pre + (turnCount *
	 *                15))
	 * 
	 * @param turnCount the number of turns to make
	 */
	// TODO Step 2
	public int turnLeft(int turnCount) {
		this.left(15.0 * turnCount);
		degreesTurned= (turnCount * 15);
		return getDegreesTurned();
	}
	/**
	 * Turns the turtle 15 degrees to its right.
	 *
	 * @precondition none
	 * @postcondition getDegreesTurned() == (getDegreesTurned()@pre + 15)
	 */
	public void turnRight() {
		this.right(15.0);
		this.degreesTurned += 15;
	}

	/**
	 * Turns the turtle the specified number of turns (each 15 degrees) to its
	 * right.
	 *
	 * @precondition turnCount >= 0
	 * @postcondition getDegreesTurned() == (getDegreesTurned()@pre + (turnCount *
	 *                15))
	 * 
	 * @param turnCount the number of turns to make
	 */
	// TODO Step 3
	
	public int turnRight(int turnCount) {
		this.right(15.0 * turnCount);
		degreesTurned= (turnCount * 15);
		return getDegreesTurned();
	}
	
	/**
	 * Drops the turtle's tail to the ground so it will draw a line when it moves.
	 * 
	 * @precondition none
	 * @postcondition isTailDown() == true
	 */
	public void lowerTail() {
		this.penDown();
	}

	/**
	 * Lifts the turtle's tail from the ground so it won't draw a line when it
	 * moves.
	 * 
	 * @precondition none
	 * @postcondition isTailDown() == false.
	 */
	public void raiseTail() {
		this.penUp();
	}

	/**
	 * Returns the total number of pixels the turtle has moved.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the total number of pixels the turtle has moved
	 */
	public int getPixelsMoved() {
		return this.pixelsMoved;
	}

	/**
	 * Returns the total number of degrees the turtle has turned.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the total number of degrees the turtle has turned
	 */
	public int getDegreesTurned() {
		return this.degreesTurned;
	}

	/**
	 * Returns the name of the turtle.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return the name of the turtle
	 */
	public String getName() {
		return this.name;
	}
}
