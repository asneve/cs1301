package edu.westga.cs1301.sketch.controllers;

import edu.westga.cs1301.sketch.model.Turtle;

/**
 * Uses turtle objects to draw on the screen.
 * 
 * @author CS 1301
 * @version Spring 2022
 */
public class TurtleController {
	private Turtle shapeTurtle;
	private Turtle borderTurtle;

	/**
	 * Creates and initializes a new TurtleController object.
	 * 
	 * @precondition none
	 * @postcondition none
	 * 
	 */
	public TurtleController() {
		this.borderTurtle = new Turtle("border", 100);
		this.shapeTurtle = new Turtle("shape");
		
	}

	/**
	 * Draws a figure on the screen using the big turtle.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public void draw() {

		this.moveToFirstOctagon();
		
		this.drawOctagon();

		this.moveToNextOctagon();

		this.drawOctagon();

		this.moveToNextOctagon();

		this.drawOctagon();

		this.drawBorder();
		
	}

	private void moveToNextOctagon() {

		this.shapeTurtle.turnRight(6);
		
		
		this.shapeTurtle.stepForward(3);
	
		
		this.shapeTurtle.turnLeft(6);
	
		
	}

	private void moveToFirstOctagon() {
		this.shapeTurtle.stepForward(4); 
	
		this.shapeTurtle.turnRight(6);
		
		this.shapeTurtle.stepForward(3);
		
		this.shapeTurtle.turnLeft(6);
	
	}

	private void drawOctagon() {
		this.shapeTurtle.lowerTail();
		this.shapeTurtle.stepForward();
		this.shapeTurtle.turnLeft(3);
		
		
		this.shapeTurtle.stepForward();
		this.shapeTurtle.turnLeft(3);
		
		
		this.shapeTurtle.stepForward();
		this.shapeTurtle.turnLeft(3);
		
		
		this.shapeTurtle.stepForward();
		this.shapeTurtle.turnLeft(3);
		
		
		this.shapeTurtle.stepForward();
		this.shapeTurtle.turnLeft(3);
		
		
		this.shapeTurtle.stepForward();
		this.shapeTurtle.turnLeft(3);
		
		
		this.shapeTurtle.stepForward();
		this.shapeTurtle.turnLeft(3);
		
		
		this.shapeTurtle.stepForward();
		this.shapeTurtle.turnLeft(3);
	
		
		this.shapeTurtle.raiseTail();
		this.borderTurtle.hideTurtle();
		this.shapeTurtle.hideTurtle();
	}

	private void drawBorder() {
		this.borderTurtle.stepForward();
		
		this.borderTurtle.lowerTail();
		
		this.borderTurtle.stepForward(3);
		
		this.borderTurtle.turnRight(6);
	

		this.borderTurtle.stepForward(5);
	
		this.borderTurtle.turnRight(6);
		

		this.borderTurtle.stepForward(3);
	
		this.borderTurtle.turnRight(6);
	

		this.borderTurtle.stepForward(5);
	
		this.borderTurtle.turnRight(6);
		
		
		this.borderTurtle.raiseTail();
	}

	/**
	 * Print summary statistics for the Turtles
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public void printTurtleStatistics() { 
		printSingleTurtleStats(borderTurtle);
		printSingleTurtleStats(shapeTurtle);
	}

	private void printSingleTurtleStats(Turtle turtle) {
		// TODO step 7
		int pixelsMoved = turtle.getPixelsMoved();
		int degreesTurned = turtle.getDegreesTurned();
		String name = turtle.getName();
		
		System.out.println(name + " moved " + pixelsMoved + " pixels.");
		System.out.println(name + " turned " + degreesTurned + " degrees.");
		
	}
}