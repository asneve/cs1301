package edu.westga.cs1301.library.test.bookShelf;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.library.model.Book;
import edu.westga.cs1301.library.model.BookShelf;

class TestGetBook {
	/**
	 * Tests the getBook class
	 * 
	 * @author Abigail Sneve
	 * @Version CS1301 - Spring 2022
	 *
	 */
	@Test
	public void CannotBeLessThanZero() {
		BookShelf Books = new BookShelf("Spooky");
		assertThrows(IllegalArgumentException.class, () -> {
			Books.getBook(-1);
		});
	}

	@Test
	public void CannotBeEqualToSize() {
		BookShelf Books = new BookShelf("Spooky");
		Book book = new Book("Skeletons", "A boneless man", 2020, 20, 1);
		Books.addBook(book);
		assertThrows(IllegalArgumentException.class, () -> {
			Books.getBook(Books.size());
		});
	}

	public void isOneLessThanSize() {
		BookShelf Books = new BookShelf("Spooky");
		Book book = new Book("Skeletons", "A boneless man", 2020, 20, 1);
		Books.addBook(book);
		Books.getBook(Books.size() - 1);
		assertEquals(Books.getBook(Books.size() - 1), book);
	}

	@Test
	public void TestgetFirstBook() {
		BookShelf Books = new BookShelf("Spooky");
		Book book = new Book("Skeletons", "A boneless man", 2020, 20, 1);
		Book book2 = new Book("Transparency", "a solid man", 2022, 20, 1);
		Book book3 = new Book("BOO", "a child", 2021, 20, 1);
		Books.addBook(book);
		Books.addBook(book2);
		Books.addBook(book3);
		assertEquals(Books.getBook(0), book);
	}

	@Test
	public void TestgetSecondBook() {
		BookShelf Books = new BookShelf("Spooky");
		Book book = new Book("Skeletons", "A boneless man", 2020, 20, 1);
		Book book2 = new Book("Transparency", "a solid man", 2022, 20, 1);
		Book book3 = new Book("BOO", "a child", 2021, 20, 1);
		Books.addBook(book);
		Books.addBook(book2);
		Books.addBook(book3);
		assertEquals(Books.getBook(1), book2);
	}

	@Test
	public void TestgetThirdBook() {
		BookShelf Books = new BookShelf("Spooky");
		Book book = new Book("Skeletons", "A boneless man", 2020, 20, 1);
		Book book2 = new Book("Transparency", "a solid man", 2022, 20, 1);
		Book book3 = new Book("BOO", "a child", 2021, 20, 1);
		Books.addBook(book);
		Books.addBook(book2);
		Books.addBook(book3);
		assertEquals(Books.getBook(2), book3);
	}

}
