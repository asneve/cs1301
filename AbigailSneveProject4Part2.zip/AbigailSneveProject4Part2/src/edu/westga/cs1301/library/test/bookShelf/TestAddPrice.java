package edu.westga.cs1301.library.test.bookShelf;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.library.model.Book;
import edu.westga.cs1301.library.model.BookShelf;

class TestAddPrice {
	/**
	 * Tests the addPrice class
	 * 
	 * @author Abigail Sneve
	 * @Version CS1301 - Spring 2022
	 *
	 */

	@Test
	public void oneBookInTheRating() {
		BookShelf Books = new BookShelf("Spooky");
		Book book = new Book("Skeletons", "A boneless man", 1999, 20, 5);
		Books.addBook(book);
		ArrayList<Book> rated = Books.addPrice();
		assertEquals(Books.addPrice().toString(), rated.toString());
	}

	@Test
	public void twoBooksWithDifferentRatings() {
		BookShelf Books = new BookShelf("Spooky");
		Book book = new Book("Skeletons", "A boneless man", 1999, 20, 1);
		Book book2 = new Book("Skeletons", "A boneless man", 1999, 20, 4);
		Books.addBook(book);
		Books.addBook(book2);
		ArrayList<Book> rated = Books.getBookOfRating(1);
		assertEquals(Books.getBookOfRating(1).toString(), rated.toString());
	}

	@Test
	public void twoBooksWithSameRatings() {
		BookShelf Books = new BookShelf("Spooky");
		Book book = new Book("Skeletons", "A boneless man", 1999, 20, 1);
		Book book2 = new Book("Skeletons", "A boneless man", 1979, 20, 1);
		Books.addBook(book);
		Books.addBook(book2);
		ArrayList<Book> rated = Books.getBookOfRating(1);
		assertEquals(Books.getBookOfRating(1).toString(), rated.toString());
	}

	@Test
	public void NoBooksWithRating() {
		BookShelf Books = new BookShelf("Spooky");
		Book book = new Book("Skeletons", "A boneless man", 1999, 20, 1);
		Book book2 = new Book("Skeletons", "A boneless man", 1979, 20, 1);
		Books.addBook(book);
		Books.addBook(book2);
		ArrayList<Book> rated = Books.getBookOfRating(5);
		assertEquals(Books.getBookOfRating(5).toString(), rated.toString());
	}

	@Test
	public void CannotBeMoreThanMaximumRating() {
		BookShelf Books = new BookShelf("Spooky");
		assertThrows(IllegalArgumentException.class, () -> {
			Books.getBookOfRating(Book.getMaximumRating() + 1);
		});
	}

	@Test
	public void CannotBeLessThanMinimumRating() {
		BookShelf Books = new BookShelf("Spooky");
		assertThrows(IllegalArgumentException.class, () -> {
			Books.getBookOfRating(Book.getMinimumRating() - 1);
		});
	}

}
