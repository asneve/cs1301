package edu.westga.cs1301.library.test.bookShelf;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.library.model.Book;
import edu.westga.cs1301.library.model.BookShelf;

class TestAddBook {
	/**
	 * Tests the addBookt class
	 * 
	 * @author Abigail Sneve
	 * @Version CS1301 - Spring 2022
	 *
	 */

	@Test
	public void shouldNotAllowNullGenre() {
		assertThrows(IllegalArgumentException.class, () -> {
			BookShelf Books = new BookShelf(null);
		});
	}

	@Test
	public void shouldNotAllowBlankGenre() {
		assertThrows(IllegalArgumentException.class, () -> {
			BookShelf Books = new BookShelf("");
		});
	}

	@Test
	public void shouldNotAllowWhiteSpeaceGenre() {
		assertThrows(IllegalArgumentException.class, () -> {
			BookShelf Books = new BookShelf("    ");
		});
	}

	@Test
	public void shouldAddOneBookToEmpty() {
		BookShelf Books = new BookShelf("Spooky");
		Book book = new Book("Skeletons", "A boneless man", 2020, 20, 1);
		Books.addBook(book);
		ArrayList<Book> bookShelf = Books.getBooks();

		assertEquals(book.toString(), bookShelf.get(0).toString());
		assertEquals(Books.addBook(book), true);
	}

	@Test
	public void shouldAddOneBookToFull() {
		BookShelf Books = new BookShelf("Spooky");
		Book book = new Book("Skeletons", "A boneless man", 2020, 20, 1);
		Book newbook = new Book("Ghosts", "A man with bones", 2021, 20, 5);
		Books.addBook(book);
		Books.addBook(book);
		Books.addBook(book);
		ArrayList<Book> bookShelf = Books.getBooks();
		bookShelf.add(newbook);
		assertEquals(newbook, bookShelf.get(bookShelf.size() - 1));
		assertEquals(Books.addBook(book), true);
	}

}
