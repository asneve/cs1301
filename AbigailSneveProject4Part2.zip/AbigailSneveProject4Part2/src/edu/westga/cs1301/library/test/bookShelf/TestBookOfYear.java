package edu.westga.cs1301.library.test.bookShelf;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.library.model.Book;
import edu.westga.cs1301.library.model.BookShelf;

class TestBookOfYear {

	@Test
	public void oneBookInTheYear() {
		BookShelf Books = new BookShelf("Spooky");
		Book book = new Book("Skeletons", "A boneless man", 1999, 20, 1);
		Books.addBook(book);
		assertEquals(1,Books.booksOfYear(1999));
		}
	@Test
	public void multiBookInTheYear() {
		BookShelf Books = new BookShelf("Spooky");
		Book book = new Book("Skeletons", "A boneless man", 1999, 20, 1);
		Books.addBook(book);
		Books.addBook(book);
		assertEquals(2,Books.booksOfYear(1999));
		}
	@Test
	public void noBookInTheYear() {
		BookShelf Books = new BookShelf("Spooky");
		assertEquals(0,Books.booksOfYear(1999));
		}

	@Test
	public void CannotBeLessThanMinimumYear() {
		BookShelf Books = new BookShelf("Spooky");
		assertThrows(IllegalArgumentException.class, () -> {
			Books.booksOfYear(Book.getEarliestYear()-1);
		});
	}
	@Test
	public void CannotBeMoreThanMaximumYear() {
		BookShelf Books = new BookShelf("Spooky");
		assertThrows(IllegalArgumentException.class, () -> {
			Books.booksOfYear(Book.getMaximumYear()+1);
		});
	}

}
