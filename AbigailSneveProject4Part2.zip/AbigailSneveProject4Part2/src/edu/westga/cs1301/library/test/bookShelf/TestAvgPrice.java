package edu.westga.cs1301.library.test.bookShelf;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.library.model.Book;
import edu.westga.cs1301.library.model.BookShelf;

class TestAvgPrice {
	/**
	 * Tests the avgPrice class
	 * 
	 * @author Abigail Sneve
	 * @Version CS1301 - Spring 2022
	 *
	 */

	@Test
	public void shouldGetAvgPriceOfOneBook() {
		BookShelf Books = new BookShelf("Spooky");
		Book book = new Book("Skeletons", "A boneless man", 2020, 20, 1);
		Books.addBook(book);
		assertEquals(Books.avgPrice(), 20);
	}

	@Test
	public void shouldGetAvgPriceOfThreeBook() {
		BookShelf Books = new BookShelf("Spooky");
		Book book = new Book("Skeletons", "A boneless man", 2020, 20, 1);
		Book book2 = new Book("Skeletons", "A boneless man", 2020, 2, 1);
		Books.addBook(book);
		Books.addBook(book2);
		assertEquals(Books.avgPrice(), 11);
	}

	@Test
	public void noBooksToAverage() {
		BookShelf Books = new BookShelf("Spooky");
		assertThrows(IllegalArgumentException.class, () -> {
			Books.avgPrice();
		});

	}
}
