package edu.westga.cs1301.library.test.bookShelf;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import edu.westga.cs1301.library.model.BookShelf;

class TestConstructor {

	/**
	 * Tests the bookShelf constructor
	 * 
	 * @author Abigail Sneve
	 * @Version CS1301 - Spring 2022
	 *
	 */

	@Test
	public void shouldNotAllowNullGenre() {
		assertThrows(IllegalArgumentException.class, () -> {
			new BookShelf(null);
		});
	}

	@Test
	public void shouldNotAllowBlankGenre() {
		assertThrows(IllegalArgumentException.class, () -> {
			new BookShelf("");
		});
	}

	@Test
	public void shouldNotAllowWhiteSpeaceGenre() {
		assertThrows(IllegalArgumentException.class, () -> {
			new BookShelf("    ");
		});
	}

	@Test
	public void shouldCreatBookShelf() {
		BookShelf BookShelfs = new BookShelf("Spooky");
		assertEquals("Spooky", BookShelfs.getGenre());
	}
}