package edu.westga.cs1301.library.model;

import java.util.Date;

/**
 * Create a book object
 * 
 * @author Abigail Sneve
 * @version Spring 2022
 *
 */

public class Book {
	private static double minimumPrice = 0.99;
	private static int earliestYear = 1900;
	private static int minimumRating = 1;
	private static int maximumRating = 5;
	private static int maximumYear = 2022;

	private String title;
	private String author;
	private int publishYear;
	private double price;
	private int rating;

	/**
	 * Creates a new book and set the values to a default value
	 *
	 * @postcondition getTitle = title; getAuthor = author; getPublishYear =
	 *                publishYear; getPrice = price; getRating = rating
	 * 
	 */
	public Book() {
		this.publishYear = earliestYear;
		this.price = minimumPrice;
		this.rating = minimumRating;
		this.title = null;
		this.author = null;

	}

	/**
	 * Creates a new book with five parameters
	 *
	 * @precondition title cannot be null or empty, author cannot be null or empty
	 *               publish year must be after 1900, price must be higher than
	 *               minimum_price, rating must be 1 to 5 inclusive.
	 * @postcondition getTitle = title; getAuthor = author; getPublishYear =
	 *                publishYear; getPrice = price; getRating = rating
	 * @param title       tile of the book
	 * @param author      name of the author of the book
	 * @param publishYear year that the book was published
	 * @param price       the price of the book
	 * @param rating      rating of the book from 1 to 5.
	 */

	public Book(String title, String author, int publishYear, double price, int rating) {
		if (title == null) {
			throw new IllegalArgumentException("title cannot be null");
		}
		if (title.isEmpty()) {
			throw new IllegalArgumentException("title cannot be empty");
		}
		if (publishYear < earliestYear) {
			throw new IllegalArgumentException("year cannot be before 1900");
		}
		if (price < minimumPrice) {
			throw new IllegalArgumentException("Price cannot be smaller than min price");
		}
		if (rating < minimumRating) {
			throw new IllegalArgumentException("rating has to be 1 or greater");
		}
		if (rating > maximumRating) {
			throw new IllegalArgumentException("rating is higher than 5");
		}
		this.title = title;
		this.author = author;
		this.publishYear = publishYear;
		this.price = price;
		this.rating = rating;
	}

	/**
	 * create a special to string method
	 * 
	 * @return returns the string created
	 */
	@Override
	public String toString() {
		return "Book [title=" + this.title + ", author=" + this.author + ", publishYear=" + this.publishYear
				+ ", price=" + this.price + ", rating=" + this.rating + "]";
	}

	/**
	 * getter for the title variable
	 * 
	 * @return the title
	 */
	public String getTitle() {

		return this.title;
	}

	/**
	 * getter for the author variable
	 * 
	 * @return the author
	 */
	public String getAuthor() {
		return this.author;
	}

	/**
	 * getter for the publish year variable
	 * 
	 * @return the publishYear
	 */
	public int getPublishYear() {
		return this.publishYear;
	}

	/**
	 * getter for the price variable
	 * 
	 * @return the price
	 */
	public double getPrice() {
		return this.price;
	}

	/**
	 * getter for the rating variable
	 * 
	 * @return the rating
	 */
	public int getRating() {
		return this.rating;
	}

	/**
	 * sets the price
	 * 
	 * @param price the price to set
	 */

	public void setPrice(double price) {
		this.price = price;
	}

	/**
	 * sets the rating variable
	 * 
	 * @param rating the rating to set
	 */
	public void setRating(int rating) {
		this.rating = rating;
	}

	public static int getEarliestYear() {
		// TODO Auto-generated method stub
		return earliestYear;
	}

	/**
	 * @return the minimumPrice
	 */
	public static double getMinimumPrice() {
		return minimumPrice;
	}

	/**
	 * @return the maximumRating
	 */
	public static int getMaximumRating() {
		return maximumRating;
	}

	/**
	 * @return the minimumRating
	 */
	public static int getMinimumRating() {
		return minimumRating;
	}

	/**
	 * @return the maximumYear
	 */
	public static int getMaximumYear() {
		return maximumYear;
	}

}
