package edu.westga.cs1301.library.model;

import java.util.ArrayList;

/**
 * creates a bookshelf
 * 
 * @author Abby Sneve
 * @version Spring 2022
 */

public class BookShelf {
	private ArrayList<Book> books;
	private ArrayList<Book> ratings;
	private ArrayList<Book> popularBook;
	private String genre;

	/**
	 * creates a bookshelf with a certain genre creates the book array list
	 * @precondition genre cannot be null
	 * @precondition genre cannot be empty
	 * @precondition genre cannot be blank
	 * @param genre the genre of the bookshelf
	 */

	public BookShelf(String genre) {
		this.genre = genre;
		if (genre == null) {
			throw new IllegalArgumentException("cannot be null");
		}
		if (genre.isEmpty()) {
			throw new IllegalArgumentException("cannot be empty");
		}
		if (genre.isBlank()) {
			throw new IllegalArgumentException("cannot be Blank");
		}
		this.books = new ArrayList<Book>();
		this.ratings = new ArrayList<Book>();
	}

	/**
	 * takes a Book object as a parameter and adds it to the shelf
	 * @precondition you cant have null books
	 * @param book the book you are adding
	 * @return boolean if a book was added or not
	 */

	public Boolean addBook(Book book) {
		if (book == null) {
			throw new IllegalArgumentException("cannot have null books");
		}
		this.books.add(book);
		for (Book bookShelf : this.books) {
			if (bookShelf.toString().equals(book.toString())) {
				return true;
			}

		}

		return false;
	}

	/**
	 * returns the books within the bookshelf
	 * 
	 * @return the books
	 */

	public int size() {
		return this.books.size();
	}

	/**
	 * Add a public method that finds and returns the average price in the
	 * bookshelf.
	 * 
	 * @precondition the array list cannot equal 0
	 * @return price the average price of the books on the shelf
	 */
	public double avgPrice() {
		double price = 0;
		if (this.books.size() <= 0) {
			throw new IllegalArgumentException("there are no prices to average");
		}
		for (Book bookShelf : this.books) {
			price = price + bookShelf.getPrice();
		}
		price = price / this.books.size();
		return price;
	}

	/**
	 * gets the book at a certain index
	 * 
	 * @precondition size cannot equal the parameter
	 * @precondition bookNum cannot be less than zero
	 * @param bookNum the book index you wish to get
	 * @return gets the book at that number
	 */

	public Book getBook(int bookNum) {
		if (bookNum == this.books.size()) {
			throw new IllegalArgumentException("cannot get outside the collection");
		}
		if (bookNum < 0) {
			throw new IllegalArgumentException("cannot get outside the collection");
		}

		for (Book currBookShelf : this.books) {
			if (this.books.indexOf(currBookShelf) == bookNum) {
				return this.books.get(bookNum);
			}
		}
		return null;
	}

	/**
	 * Add a method to Bookshelf that determines the number of books published in a
	 * specific year given by a parameter.
	 * 
	 * @precondition year cannot be less then earliest year
	 * @precondition cannot be latter than maximum Year
	 * @param year year you want to look up
	 * @return the number of books publish within the year
	 */
	public int booksOfYear(int year) {
		int numOfBooks = 0;
		if (year < Book.getEarliestYear()) {
			throw new IllegalArgumentException("books cannot be made before earliest year");
		}
		if (year > Book.getMaximumYear()) {
			throw new IllegalArgumentException("books cannot be made after this year");
		}
		for (Book currBookShelf : this.books) {

			if (currBookShelf.getPublishYear() == year) {
				numOfBooks = numOfBooks + 1;
			}
		}
		return numOfBooks;
	}

	/**
	 * returns a list of all books with a certain rating (
	 * 
	 * @precondition rating cannot be below min rating
	 * @precondition rating cannnot be higher than max rating
	 * @param rating rating you want to look up
	 * @return ratings the array list of books with the requested rating
	 */
	public ArrayList<Book> getBookOfRating(int rating) {
		if (rating < Book.getMinimumRating()) {
			throw new IllegalArgumentException("cannot get outside the rating restraint");
		}
		if (rating > Book.getMaximumRating()) {
			throw new IllegalArgumentException("cannot be above the rating restraint");
		}

		for (Book currBookShelf : this.books) {
			if (currBookShelf.getRating() == rating) {
				this.ratings.add(currBookShelf);
			}
		}
		return this.ratings;
	}

	/**
	 * adds $1.00 to the price of all books with a rating of 4 or higher.
	 * 
	 * @return popularBook return arraylist of popularBooks.
	 */

	public ArrayList<Book> addPrice() {
		for (Book currBookShelf : this.books) {
			if (currBookShelf.getRating() == 4) {
				currBookShelf.setPrice(currBookShelf.getPrice() + 1);
				this.popularBook.add(currBookShelf);

			}
			if (currBookShelf.getRating() == 5) {
				currBookShelf.setPrice(currBookShelf.getPrice() + 1);
				this.popularBook.add(currBookShelf);
			}
		}
		return this.popularBook;
	}

	/**
	 * public method that computes and returns the price of the most expensive Book
	 * 
	 * @precondition size cannot equal or be less than zero
	 * @return exp the most expensive book
	 */
	public Book getExp() {
		if (this.books.size() <= 0) {
			throw new IllegalArgumentException("no books to compare");
		}
		double price = 0;
		Book exp = null;
		for (Book currBookShelf : this.books) {
			if (currBookShelf.getPrice() > price) {
				price = currBookShelf.getPrice();
				exp = currBookShelf;
			}

		}
		return exp;
	}

	/**
	 * gets the books in the array
	 * 
	 * @return the array list of books
	 */

	public ArrayList<Book> getBooks() {
		return this.books;
	}

	/**
	 * returns the genre of the book
	 * 
	 * @return the genre
	 */

	public String getGenre() {
		return this.genre;
	}

}
