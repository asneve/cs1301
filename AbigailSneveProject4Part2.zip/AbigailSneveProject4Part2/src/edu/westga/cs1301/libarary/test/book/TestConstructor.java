package edu.westga.cs1301.libarary.test.book;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.library.model.Book;

class TestConstructor {

	/**
	 * Tests the Book class
	 * 
	 * @author Abigail Sneve CS1301 - Spring 2022
	 *
	 */

	@Test
	public void nullTitle() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Book(null, "cake", 0, 0, 0);
		});
	}

	@Test
	public void emptyTitle() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Book("", "jake", 0, 0, 0);
		});
	}

	@Test
	public void nullAuthor() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Book("cake", null, 0, 0, 0);
		});
	}

	@Test
	public void EmptyAuthor() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Book("cake", "", 0, 0, 0);
		});
	}

	@Test
	public void OutOfYearBoundry() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Book("cake", "jake", 1899, 0, 0);
		});
	}

	@Test
	public void OutOfPriceBoundry() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Book("cake", "jake", 1999, 0.98, 0);
		});
	}

	@Test
	public void TooLowOfRatingBoundry() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Book("cake", "jake", 1999, 0.99, 0);
		});
	}

	@Test
	public void TooHighOfRatingBoundry() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Book("cake", "jake", 1999, 0.99, 6);
		});
	}

	@Test
	public void shouldCreateBook() {
		Book book = new Book("Cake", "jake", 1999, 20, 4);
		assertEquals("Cake", book.getTitle());
		assertEquals("jake", book.getAuthor());
		assertEquals(1999, book.getPublishYear());
		assertEquals(20, book.getPrice());
		assertEquals(4, book.getRating());
	}
}
