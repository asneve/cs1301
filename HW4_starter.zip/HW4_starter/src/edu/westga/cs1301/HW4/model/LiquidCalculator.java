package edu.westga.cs1301.HW4.model;

/**
 * This class can be used to perform some useful calculations
 * 	with liquid measurements.
 * 
 * @author	Abigail Sneve CS1301
 * @version	Spring 2022
 *
 */
public class LiquidCalculator {
	private static final String CONVERSION_UNITS = "gallons, quarts, pints, cups";
	/**
	 * Converts the total number of cups into an equivalent number of
	 *  gallons, quarts, pints, and cups in the form:
	 *		G gallons, Q quarts, P pints, and C cups
	 *  where 	G = the number of gallons
	 *  		Q = the number of quarts
	 *  		P = the number of pints
	 *  		C = the number of cups
	 * Example: If totalCups is 123 then that is:
	 * 
	 * 			7 gallons 	(112 cups)
	 * 			2 quarts 	(+8 cups)
	 * 			1 pints 	(+2 cups)
	 * 			1 cups		(+1 cups, for a total of 123 cups)
	 * 
	 * this produces the String: 7 gallons, 2 quarts, 1 pints, and 1 cups
	 * 
	 * @precondition	totalCups >= 0
	 * @postcondition	none
	 * 
	 * @param	totalCups	the total number of cups to be converted
	 * @return	the amount of liquid formatted as specified above
	 */
	public String getLiquidBreakdown(int totalCups) {
		// TODO #4:
		return "0 gallons, 0 quarts, 0 pints, and 0 cups";
	}
	
	/**
	 * This method can be used to get a single whole number amount of a 
	 * specific unit of measure. 
	 * 
	 * For example, 
	 * 		If the the totalCups is 5 and the unit is "quarts",
	 * 			then "1 quarts" is returned. 
	 * 		If totalCups is 32 and the unit is "gallons", 
	 * 			then "2 gallons" is returned. No decimal values 
	 * 		If totalCups is 8 and the unit is "gallons", 
	 * 			then "0 gallons" is returned. No decimal values 
	 * 		will be measured.
	 * 
	 * @precondition totalCups >= 0 
	 * 				&& unit != null > 0 
	 * 				&& !unit.isEmpty()
	 * 				&& CONVERSION_UNITS.contains(unit)
	 * 
	 * @postcondition none
	 * 
	 * @param totalCups the total number of cups to be divided
	 * @param unit the unit of measure to calculate ( value is limited 
	 * 			to either 'gallons', 'quarts', or 'pints', or 'cups'.
	 * 
	 * @return the resulting amount after totalCups is divided by two
	 */
	public String getBreakdownBySpecificUnit(int totalCups, String unit) {
		// TODO #3: Enforce the preconditions 
	if (unit == null) {
		throw new IllegalArgumentException("unit is null");
	}
	if (totalCups < 0) {
		throw new IllegalArgumentException("cups are invaild");
	}
	if (totalCups == 1 && totalCups== 0) {
		throw new IllegalArgumentException("cup is empty");
	}
		String output = "";
		if(unit.equals("gallons")) {
			output = (totalCups / 16) + " " + unit;
		} else if (unit.equals("quarts")) {
			output = (totalCups / 4) + " " + unit;
		} else if (unit.equals("pints")) {
			output = (totalCups / 2) + " " + unit;
		} else if (unit.equals("cups")) {
			output = (totalCups / 1) + " " + unit;
		} else {
			throw new IllegalArgumentException("Invaild units");
		}
	;
	
		return output;
	}
	/**
	 * This method can be used to divide an amount in half.  Note that
	 *  if a fractional number of cups results, we'll round up to the next
	 *  highest cup.  For example, 3.5 cups will be 4 cups, but 3.4 cups will be 3 cups.
	 *  
	 * @precondition	totalCups >= 0
	 * 
	 * @postcondition	A String representing the resulting amount after
	 * 					totalCups is divided by divideFactor
	 * 
	 * @param	totalCups		the total number of cups to be divided
	 * 
	 * @return	the resulting amount after
	 * 			totalCups is divided by two
	 */
	public String divideByTwo(int totalCups) {
		// TODO #5: Correct the bug(s)
		
		double roundedValue = Math.round(totalCups);
		int result = (int)(roundedValue / 2);
		return this.getLiquidBreakdown(result);
	}	
	
	// TODO #6: Write a method from Scratch.
}
