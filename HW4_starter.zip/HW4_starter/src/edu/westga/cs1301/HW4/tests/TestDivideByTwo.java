package edu.westga.cs1301.HW4.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.HW4.model.LiquidCalculator;

/**
 * This class contains a variety of tests to confirm correct functionality
 *  of the divideByTwo method
 *  
 * @author	CS1301
 * @version	Spring 2022
 *
 */
public class TestDivideByTwo {
	@Test
	public void testInvalidTotalCups() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		assertThrows(IllegalArgumentException.class, ()->{
			theCalculator.divideByTwo(-1);
		});
	}
	
	@Test
	public void testDivideOneGallonByTwoIsTwoQuarts() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.divideByTwo(16);
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("0 gallons, 2 quarts, 0 pints, and 0 cups", actualResult);
	}

	@Test
	public void testDivideOneCupByOneIsOneCup() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.divideByTwo(1);
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("0 gallons, 0 quarts, 0 pints, and 1 cups", actualResult);
	}
	

	@Test
	public void testDivideTwoCupsByTwoIsOneCup() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.divideByTwo(2);
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("0 gallons, 0 quarts, 0 pints, and 1 cups", actualResult);
	}
	
	@Test
	public void testDivideTwoQuartsByTwoIsOneQuart() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.divideByTwo(8);
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("0 gallons, 1 quarts, 0 pints, and 0 cups", actualResult);
	}
	
	
	@Test
	public void testDivideTwoPintsByTwoIsOneCup() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.divideByTwo(2);
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("0 gallons, 0 quarts, 0 pints, and 1 cups", actualResult);
	}
}
