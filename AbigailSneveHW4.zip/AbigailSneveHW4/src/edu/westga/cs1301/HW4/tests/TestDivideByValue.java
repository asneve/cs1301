package edu.westga.cs1301.HW4.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edu.westga.cs1301.HW4.model.LiquidCalculator;

/**
 * This class contains a variety of tests to confirm correct functionality
 *  of the divideByValue method
 *  
 * @author	CS1301
 * @version	Spring 2022
 *
 */
public class TestDivideByValue {
//	@Test
//	public void testInvalidTotalCupsLessThanZero() {
//		// Arrange: create a LiquidCalculator object
//		LiquidCalculator theCalculator = new LiquidCalculator();
//		
//		assertThrows(IllegalArgumentException.class, ()->{
//			theCalculator.divideByValue(-1, 1.0);
//		});
//	}
//
//	@Test
//	public void testInvalidAmountToDivideByLessThanZero() {
//		// Arrange: create a LiquidCalculator object
//		LiquidCalculator theCalculator = new LiquidCalculator();
//		
//		assertThrows(IllegalArgumentException.class, ()->{
//			theCalculator.divideByValue(1, -1.0);
//		});
//	}
//
//	@Test
//	public void testInvalidAmountToDivideByEqualsZero() {
//		// Arrange: create a LiquidCalculator object
//		LiquidCalculator theCalculator = new LiquidCalculator();
//		
//		assertThrows(IllegalArgumentException.class, ()->{
//			theCalculator.divideByValue(1, 0.0);
//		});
//	}
//
//	@Test
//	void testDivideOneGallonByTwoIsTwoQuarts() {
//		// Arrange: create a LiquidCalculator object
//		LiquidCalculator theCalculator = new LiquidCalculator();
//		
//		// Act: call our method with proper parameter value for our test
//		String actualResult = theCalculator.divideByValue(16, 2);
//		
//		// Assert: assert that our expected value is equal to the actual result
//		assertEquals("0 gallons, 2 quarts, 0 pints, and 0 cups", actualResult);
//	}
//
//	@Test
//	void testDivideOneGallonByThreeIsOneQuartsOneCup() {
//		// Arrange: create a LiquidCalculator object
//		LiquidCalculator theCalculator = new LiquidCalculator();
//		
//		// Act: call our method with proper parameter value for our test
//		String actualResult = theCalculator.divideByValue(16, 3);
//		
//		// Assert: assert that our expected value is equal to the actual result
//		assertEquals("0 gallons, 1 quarts, 0 pints, and 1 cups", actualResult);
//	}
//	
//
//	@Test
//	void testDivideTwoGallonsByFiveIsOneQuartsOnePint() {
//		// Arrange: create a LiquidCalculator object
//		LiquidCalculator theCalculator = new LiquidCalculator();
//		
//		// Act: call our method with proper parameter value for our test
//		String actualResult = theCalculator.divideByValue(32, 5);
//		
//		// Assert: assert that our expected value is equal to the actual result
//		assertEquals("0 gallons, 1 quarts, 1 pints, and 0 cups", actualResult);
//	}
//	
//	@Test
//	void testDivideOneCupByTwoIsZeroPints() {
//		// Arrange: create a LiquidCalculator object
//		LiquidCalculator theCalculator = new LiquidCalculator();
//		
//		// Act: call our method with proper parameter value for our test
//		String actualResult = theCalculator.divideByValue(1, 2);
//		
//		// Assert: assert that our expected value is equal to the actual result
//		assertEquals("0 gallons, 0 quarts, 0 pints, and 0 cups", actualResult);
//	}
//	
//	
//	@Test
//	void testDivideSixGallonsByFiveIsOneGallonOnePintOneCup() {
//		// Arrange: create a LiquidCalculator object
//		LiquidCalculator theCalculator = new LiquidCalculator();
//		
//		// Act: call our method with proper parameter value for our test
//		String actualResult = theCalculator.divideByValue(96, 5);
//		
//		// Assert: assert that our expected value is equal to the actual result
//		assertEquals("1 gallons, 0 quarts, 1 pints, and 1 cups", actualResult);
//	}
}
