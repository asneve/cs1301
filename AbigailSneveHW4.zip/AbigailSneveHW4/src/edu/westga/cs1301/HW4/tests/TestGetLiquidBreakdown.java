package edu.westga.cs1301.HW4.tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import edu.westga.cs1301.HW4.model.LiquidCalculator;

/**
 * This class contains a variety of tests to confirm correct functionality
 *  of the getLiquidBreakdown method
 *  
 * @author	CS1301
 * @version	Spring 2022
 *
 */
public class TestGetLiquidBreakdown {
	@Test
	public void testInvalidTotalCups() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		assertThrows(IllegalArgumentException.class, ()->{
			theCalculator.divideByTwo(-1);
		});
	}
	@Test
	public void testShouldHaveZeroForGallonsQuartsPintsAndCups() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getLiquidBreakdown(0);
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("0 gallons, 0 quarts, 0 pints, and 0 cups", actualResult);
	}

	@Test
	public void testShouldProduce4Gallons() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getLiquidBreakdown(64);
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("4 gallons, 0 quarts, 0 pints, and 0 cups", actualResult);
	}
	
	@Test
	public void testShouldProduce2Gallons3Quarts() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getLiquidBreakdown(44);
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("2 gallons, 3 quarts, 0 pints, and 0 cups", actualResult);
	}
	
	@Test
	public void testShouldProduce1Gallons2Quarts1Pints() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getLiquidBreakdown(26);
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("1 gallons, 2 quarts, 1 pints, and 0 cups", actualResult);
	}
	
	@Test
	public void testShouldProduce4Gallons3Quarts1Pints1Cups() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getLiquidBreakdown(79);
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("4 gallons, 3 quarts, 1 pints, and 1 cups", actualResult);
	}
}
