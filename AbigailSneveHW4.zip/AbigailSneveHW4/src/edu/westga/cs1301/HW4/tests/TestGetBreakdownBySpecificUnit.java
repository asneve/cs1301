package edu.westga.cs1301.HW4.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.westga.cs1301.HW4.model.LiquidCalculator;

/**
 * This class contains a variety of tests to confirm correct functionality
 *  of the getBreakdownBySpecificUnit method
 *  
 * @author	CS1301
 * @version	Spring 2022
 *
 */
class TestGetBreakdownBySpecificUnit {

	@Test
	void testInvalidTotalCups() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		assertThrows(IllegalArgumentException.class, ()->{
			// Assert: assert that our expected value is equal to the actual result
			theCalculator.getBreakdownBySpecificUnit(-1, "gallons");
		});
	}
	
	@Test
	void testInvalidUnitsIsEmpty() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		assertThrows(IllegalArgumentException.class, ()->{
			// Assert: assert that our expected value is equal to the actual result
			theCalculator.getBreakdownBySpecificUnit(1, "");
		});
	}
	@Test
	void testInvalidUnitsIsNull() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		assertThrows(IllegalArgumentException.class, ()->{
			// Assert: assert that our expected value is equal to the actual result
			theCalculator.getBreakdownBySpecificUnit(1, null);
		});
	}
	@Test
	void testInvalidUnitsNotContainedInConversionUnits() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		assertThrows(IllegalArgumentException.class, ()->{
			// Assert: assert that our expected value is equal to the actual result
			theCalculator.getBreakdownBySpecificUnit(1, "null");
		});
	}
	@Test
	void testGallonsZero() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getBreakdownBySpecificUnit(0, "gallons");
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("0 gallons", actualResult);
	}

	@Test
	void testGallonsGreaterThanZeroButLessThanOneGallon() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getBreakdownBySpecificUnit(15, "gallons");
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("0 gallons", actualResult);
	}
	@Test
	void testGallonsGreaterThanZeroButMoreThanOneGallon() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getBreakdownBySpecificUnit(17, "gallons");
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("1 gallons", actualResult);
	}
	@Test
	void testGallonsGreaterThanZeroButExactlyOneGallon() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getBreakdownBySpecificUnit(16, "gallons");
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("1 gallons", actualResult);
	}
	
	@Test
	void testQuartsZero() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getBreakdownBySpecificUnit(0, "quarts");
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("0 quarts", actualResult);
	}

	@Test
	void testQuartsGreaterThanZeroButLessThanOneQuart() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getBreakdownBySpecificUnit(3, "quarts");
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("0 quarts", actualResult);
	}
	@Test
	void testQuartsGreaterThanZeroButMoreThanOneQuart() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getBreakdownBySpecificUnit(5, "quarts");
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("1 quarts", actualResult);
	}
	@Test
	void testQuartsGreaterThanZeroButExactlyOneQuart() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getBreakdownBySpecificUnit(4, "quarts");
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("1 quarts", actualResult);
	}
	@Test
	void testPintsZero() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getBreakdownBySpecificUnit(0, "pints");
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("0 pints", actualResult);
	}

	@Test
	void testPintsGreaterThanZeroButLessThanOnePint() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getBreakdownBySpecificUnit(1, "pints");
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("0 pints", actualResult);
	}
	@Test
	void testPintsGreaterThanZeroButMoreThanOnePint() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getBreakdownBySpecificUnit(3, "pints");
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("1 pints", actualResult);
	}
	@Test
	void testPintsGreaterThanZeroButExactlyOnePint() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getBreakdownBySpecificUnit(2, "pints");
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("1 pints", actualResult);
	}
	@Test
	void testCupsGreaterThanZeroButExactlyOneCup() {
		// Arrange: create a LiquidCalculator object
		LiquidCalculator theCalculator = new LiquidCalculator();
		
		// Act: call our method with proper parameter value for our test
		String actualResult = theCalculator.getBreakdownBySpecificUnit(2, "cups");
		
		// Assert: assert that our expected value is equal to the actual result
		assertEquals("2 cups", actualResult);
	}
}
